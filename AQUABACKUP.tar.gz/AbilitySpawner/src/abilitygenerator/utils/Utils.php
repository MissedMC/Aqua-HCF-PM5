<?php

namespace abilitygenerator\utils;

use pocketmine\math\Vector3;

use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\DimensionIds;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;

final class Utils {

    /**
     * @param Vector3 $position
     * @param string $particleName
     * @return SpawnParticleEffectPacket
     */
    public static function addParticle(Vector3 $position, string $particleName) : SpawnParticleEffectPacket {
        return SpawnParticleEffectPacket::create(DimensionIds::OVERWORLD, -1, $position, $particleName, null);
    }

    /**
     * @param Vector3 $position
     * @param int $sound
     * @return LevelSoundEventPacket
     */
    public static function addSound(Vector3 $position, int $sound) : LevelSoundEventPacket {
        return LevelSoundEventPacket::nonActorSound($sound, $position, false, -1);
    }

    /**
     * @param Vector3 $position
     * @param string $sound
     * @return PlaySoundPacket
     */
    public static function playSound(Vector3 $position, string $sound) : PlaySoundPacket {
        return PlaySoundPacket::create($sound, $position->getFloorX(), $position->getFloorY(), $position->getFloorZ(), 4.0, 1.0);
    }
}

?>