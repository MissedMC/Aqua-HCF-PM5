<?php

namespace abilitygenerator\utils;

final class Time {

    /**
     * @param int $time
     * @return string
     */
    public static function getTimeToString(int $time) : string {
		$m = null;		
		$h = null;
        $d = null;
		if($time >= 60){			
			$m = floor(($time % 3600) / 60);		
			if($time >= 3600){				
				$h = floor(($time % 86400) / 3600);
                if($time >= 3600 * 24){
                    $d = floor($time / 86400);
                }
			}		
		}		
        if($m !== null){
            $format = "i:s";
        }
        if($h !== null){
            $format = "H:i:s";
        }
        if($d !== null){
            $format = "d:H:i:s";
        }
		return gmdate($format ?? "s", $time);
	}

    /**
     * @param int $time
     * @return string
     */
    public static function getTimeToFullString(int $time) : string {
		$s = $time % 60;	
		$m = null;		
		$h = null;		
		$d = null;
		
		if($time >= 60){			
			$m = floor(($time % 3600) / 60);		
			if($time >= 3600){				
				$h = floor(($time % 86400) / 3600);				
				if($time >= 3600 * 24){					
					$d = floor($time / 86400);					
				}			
			}		
		}		
		return ($m !== null ? ($h !== null ? ($d !== null ? "$d days " : "")."$h hours " : "")."$m minutes " : "")."$s seconds";
	}
}

?>