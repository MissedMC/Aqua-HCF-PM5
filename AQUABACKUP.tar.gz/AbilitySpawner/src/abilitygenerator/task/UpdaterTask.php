<?php

namespace abilitygenerator\task;

use abilitygenerator\AbilityMain;
use abilitygenerator\utils\Time;

use abilitygenerator\entity\NPC;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

use pocketmine\item\VanillaItems;

class UpdaterTask extends Task {

    /**
     * UpdaterTask Constructor.
     * @param NPC $entity
     * @param int $time
     */
    public function __construct(
        protected NPC $entity,
        int $time,
    ){
        $entity->updateTime = $time;
    }

    /**
     * @return void
     */
    public function onRun() : void {
        if($this->entity->isClosed() || !$this->entity->isAlive() || $this->entity->isDeath()){
            $this->getHandler()->cancel();
            return;
        }
        $contents = AbilityMain::getInstance()->getContents();
        if(count($contents) === 0){
            return;
        }
        $this->entity->setScoreTag(TextFormat::colorize("&r&7Next Drop: &e".Time::getTimeToString($this->entity->updateTime)));

        $newLore = [];
        $inventory = $this->entity->invMenu->getInventory();
        if(--$this->entity->updateTime <= 0){
            // do something
            $this->entity->contents[] = ($resultItem = $contents[array_rand($contents)]);

            $oldItem = $inventory->getItem(11);
            if(!$oldItem->isNull()){
                $newLore = $oldItem->getLore();
            }
            if(isset($newLore[1]) && $newLore[1] === TextFormat::colorize("&r&cEmpty ...")){
                $newLore[1] = "";
                // If it is the first time that we are going to do this, it is necessary to remove the line break
                unset($newLore[2]);
            }

            $newLore[1] .= TextFormat::colorize("&r&7x".$resultItem->getCount()." &r&7".($resultItem->hasCustomName() ? $resultItem->getCustomName() : $resultItem->getName())).TextFormat::EOL;

            if(!$resultItem->isNull()){
                $this->entity->updateTime = AbilityMain::getInstance()->getDefaultUpdateTime();
            }
            $this->entity->invMenu->getInventory()->setItem(11, VanillaItems::MINECART()->setCustomName(TextFormat::colorize("&r&l&6Storage"))->setLore($newLore));
        }
    }
}

?>