<?php

namespace abilitygenerator\task;

use abilitygenerator\AbilityMain;

use abilitygenerator\utils\Time;
use abilitygenerator\entity\NPC;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

class RespawnTask extends Task {

    /**
     * RespawnTask Constructor.
     * @param NPC $entity
     * @param int $time
     */
    public function __construct(
        protected NPC $entity,
        int $time,
    ){
        $entity->respawnTime = $time;
    }

    /**
     * @return void
     */
    public function onRun() : void {

        $this->entity->setScoreTag(TextFormat::colorize("&r&7Respawns in: &c".Time::getTimeToString($this->entity->respawnTime)));

        if(--$this->entity->respawnTime <= 0){

            $this->respawn();

            $this->getHandler()->cancel();
        }
    }

    /**
     * @return void
     */
    protected function respawn() : void {
        $this->entity->setSkin(AbilityMain::getInstance()->getSkin());
        $this->entity->sendSkin();

        $this->entity->setDeath(false);
        $this->entity->setHealth($this->entity->getMaxHealth());

        $this->entity->startUpdaterTask();
    }
}

?>