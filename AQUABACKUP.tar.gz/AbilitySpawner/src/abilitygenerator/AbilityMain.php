<?php

namespace abilitygenerator;

use abilitygenerator\entity\NPC;
use abilitygenerator\item\Spawner;

use pocketmine\entity\Human;
use pocketmine\entity\Skin;

use pocketmine\inventory\Inventory;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\nbt\TreeRoot;
use pocketmine\nbt\LittleEndianNbtSerializer;

use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;

use pocketmine\world\World;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginBase;

use pocketmine\item\Item;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\ItemIdentifier;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\type\InvMenuTypeIds;

class AbilityMain extends PluginBase {

    /** @var AbilityMain */
    protected static AbilityMain $instance;

    /** @var Item */
    protected Item $item;

    /** @var Skin|null */
    protected ?Skin $skin = null;

    /** @var Skin|null */
    protected ?Skin $invisibleSkin = null;

    /** @var array<int, Item> */
    protected array $contents = [];

    /**
     * @return void
     */
    public function onLoad() : void {
        self::$instance = $this;
    }

    /**
     * @return void
     */
    public function onEnable() : void {

        EntityFactory::getInstance()->register(NPC::class, function(World $world, CompoundTag $nbt) : NPC {
            return new NPC(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['NPC']);

        foreach($this->getResources() as $resource => $fileInfo){
            $this->saveResource($resource, $this->isDevelopmentVersion());
        }

        $this->loadContents();
        $this->item = new Spawner(new ItemIdentifier(ItemTypeIds::WHEAT), "Ability Spawner  Spawner", TextFormat::colorize("&r&l&dAbility Spawner &r&7 Generator"), [TextFormat::colorize("&r&7Right click into ground to spawn a &l&dAbility Spawner&r&7 Generator.&r&7".TextFormat::EOL."If dies you must wait 30 minutes for him to appear again.".TextFormat::EOL.TextFormat::EOL."")]);

        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }

        $this->getServer()->getPluginManager()->registerEvents(new MainListener(), $this);
    }

    /**
     * @return void
     */
    public function onDisable() : void {
        $this->saveContents();
    }

    /**
     * @param CommandSender $sender
     * @param Command $command
     * @param string $label
     * @param array $args
     * @return bool
     */
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if($command->getName() === "abilitygenerator"){
            if(!$sender instanceof Player){
                $sender->sendMessage(TextFormat::colorize("&cRun command in game"));
                return false;
            }
            if(count($args) <= 0){
                $sender->sendMessage(TextFormat::colorize("&cCommands: "));
                $sender->sendMessage(TextFormat::colorize("&7/abgen give"));
                $sender->sendMessage(TextFormat::colorize("&7gives you the generator."));
                $sender->sendMessage(TextFormat::colorize("&7/abgen edit"));
                $sender->sendMessage(TextFormat::colorize("&7opens a menu for edit the\n&7 ability spawner items"));
                return false;
            }
            switch($args[0]){
                case "give":
                    $amount = 1;
                    if(count($args) > 1){
                        $amount = intval($args[1]);
                    }
                    $sender->getInventory()->addItem($this->item->setCount($amount));
                break;
                case "edit":
                    $inventory = ($menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST))->getInventory();

                    $menu->setName(TextFormat::colorize("&r&l&dAbility Spawner &r&7 Generator Editor"));

                    $menu->setInventoryCloseListener(function(Player $player, Inventory $inventory) : void {

                        $this->setContents(count($inventory->getContents()) === 0 ? $this->getContents() : $inventory->getContents());
                        $this->saveContents();

                        $player->sendMessage(TextFormat::colorize("&aGenerator's contents has been saved"));
                    });

                    $menu->send($sender, callback: function(bool $sent) use ($inventory) : void { if($sent){ if(count($this->getContents()) !== 0){ $inventory->setContents($this->getContents()); }}});
                break;
            }
        }
        return true;
    }

    /**
     * @return Item
     */
    public function getSpawnerItem() : Item {
        return $this->item;
    }

    /**
     * @return int
     */
    public function getDefaultUpdateTime() : int {
        return $this->getConfig()->getNested("time-to-drop-an-item");
    }

    /**
     * @return int
     */
    public function getDefaultRespawnTime() : int {
        return $this->getConfig()->getNested("time-to-respawn-generator");
    }

    /**
     * @return bool
     */
    public function shouldRotate() : bool {
        return $this->getConfig()->getNested("rotation");
    }

    /**
     * @return Item[]
     */
    public function getContents() : array {
        return $this->contents;
    }

    /**
     * @param array $contents
     */
    public function setContents(array $contents) : void {
        $this->contents = $contents;
    }

    /**
     * @return void
     */
    protected function loadContents() : void {
        $file = $this->getDataFolder()."contents.dat";
        if(!file_exists($file)){
            $this->getLogger()->debug("Can't find ".$file);
            return;
        }
        $decompressed = @zlib_decode(file_get_contents($file));

        $nbt = (new LittleEndianNbtSerializer())->read($decompressed)->mustGetCompoundTag();
        $inventory = $nbt->getListTag("Inventory");
        if($inventory === null){
            $this->getLogger()->debug("Can't find Compound Inventory");
            return;
        }
        $contents = [];
        foreach($inventory as $item){
            /** @noinspection PhpPossiblePolymorphicInvocationInspection */
            $contents[$item->getByte("Slot")] = Item::nbtDeserialize($item);
        }
        $this->setContents($contents);
    }

    /**
     * @return void
     */
    protected function saveContents() : void {
        if(count($contents = $this->getContents()) === 0){
            return;
        }
        /** @var array<int, CompoundTag> $nbtItems */
        $nbtItems = [];
        foreach($contents as $slot => $item){
            $nbtItems[] = $item->nbtSerialize($slot);
        }
        $nbt = CompoundTag::create()->setTag("Inventory", new ListTag($nbtItems, NBT::TAG_Compound));

        file_put_contents($this->getDataFolder()."contents.dat", zlib_encode((new LittleEndianNbtSerializer())->write(new TreeRoot($nbt)), ZLIB_ENCODING_GZIP));
    }

    /**
     * @return Skin
     */
    public function getSkin() : Skin {
        if($this->skin !== null){
            return $this->skin;
        }
        $file = $this->getDataFolder()."skin.dat";
        if(!file_exists($file)){
            throw new \LogicException("Can't find ".$file);
        }
        $data = zlib_decode(file_get_contents($file));

        return ($this->skin = unserialize($data));
    }

    /**
     * @return Skin
     */
    public function getInvisibleSkin() : Skin {
        if($this->invisibleSkin !== null){
            return $this->invisibleSkin;
        }
        $file = $this->getDataFolder()."invisible_skin.dat";
        if(!file_exists($file)){
            throw new \LogicException("Can't find ".$file);
        }
        $data = zlib_decode(file_get_contents($file));

        return ($this->invisibleSkin = unserialize($data));
    }

    /**
     * @return bool
     */
    protected function isDevelopmentVersion() : bool {
        return false;
    }

    /**
     * @return static
     */
    public static function getInstance() : self {
        return self::$instance;
    }
}

?>