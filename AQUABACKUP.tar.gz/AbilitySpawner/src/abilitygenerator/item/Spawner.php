<?php

namespace abilitygenerator\item;

use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;

class Spawner extends Item {

    /**
     * @param ItemIdentifier $identifier
     * @param string $name
     * @param string $customName
     * @param array $lore
     */
    public function __construct(ItemIdentifier $identifier, string $name = "Unknown", string $customName = "Unknown", array $lore = []){
        parent::__construct($identifier, $name);

        parent::setCustomName($customName);
        parent::setLore($lore);
    }
}

?>