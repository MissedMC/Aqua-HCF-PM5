<?php

namespace abilitygenerator\entity;

use abilitygenerator\AbilityMain;
use abilitygenerator\utils\Utils;

use abilitygenerator\task\RespawnTask;
use abilitygenerator\task\UpdaterTask;

use pocketmine\item\Item;
use pocketmine\item\VanillaItems;

use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;

use pocketmine\math\Vector2;
use pocketmine\math\Vector3;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\entity\Skin;
use pocketmine\entity\Human;
use pocketmine\entity\Location;

use pocketmine\event\entity\EntityDamageEvent;

use pocketmine\network\mcpe\protocol\MovePlayerPacket;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

class NPC extends Human {

    /** @var array<int, Item> */
    public array $contents = [];

    /** @var InvMenu|null */
    public ?InvMenu $invMenu = null;

    /** @var bool */
    protected bool $isDeath = false;

    /** @var int */
    public int $updateTime = 0;

    /** @var int */
    public int $respawnTime = 0;

    /**
     * NPC Constructor.
     * @param Location $location
     * @param Skin $skin
     * @param CompoundTag|null $nbt
     */
    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null){
        parent::__construct($location, $skin, $nbt);

        $this->setupMenu();

        $this->setNameTagVisible();
        $this->setNameTagAlwaysVisible();

        $this->setNameTag(TextFormat::colorize("&r&l&dAbility Generator\n&7"));
    }

    /**
     * @param int|null $time
     * @return void
     */
    public function startUpdaterTask(int $time = null) : void {
        AbilityMain::getInstance()->getScheduler()->scheduleRepeatingTask(new UpdaterTask($this, $time ?? AbilityMain::getInstance()->getDefaultUpdateTime()), 20);
    }

    /**
     * @param int|null $time
     * @return void
     */
    public function startRespawnTask(int $time = null) : void {
        AbilityMain::getInstance()->getScheduler()->scheduleRepeatingTask(new RespawnTask($this, $time ?? AbilityMain::getInstance()->getDefaultRespawnTime()), 20);
    }

    /**
     * @return bool
     */
    public function isDeath() : bool {
        return $this->isDeath;
    }

    /**
     * @param bool $v
     */
    public function setDeath(bool $v) : void {
        $this->isDeath = $v;
    }

    /**
     * @return void
     */
    protected function setupMenu() : void {

        $inventory = ($this->invMenu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST))->getInventory();

        $inventory->setItem(11, VanillaItems::MINECART()->setCustomName(TextFormat::colorize("&r&l&6Storage"))->setLore([0 => "", 1 => TextFormat::colorize("&r&cEmpty ..."), 2 => "", 3 => TextFormat::colorize("&r&eClick to collect storage")]));
        $inventory->setItem(13, VanillaItems::BRICK()->setCustomName(TextFormat::colorize("&r&l&aStatus"))->setLore([TextFormat::EOL.TextFormat::colorize("&r&7HP&f: &c".$this->getHealth())]));
        $inventory->setItem(15, VanillaItems::VILLAGER_SPAWN_EGG()->setCustomName(TextFormat::colorize("&r&l&7Pickup"))->setLore([TextFormat::EOL.TextFormat::colorize("&r&l&cWARNING!&r&e".TextFormat::EOL."Picking up this generator".TextFormat::EOL."will make it lose all its storage!")]));

        foreach($inventory->getContents(true) as $slot => $item){
            if($item->isNull()){
                $inventory->setItem($slot, VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::BLACK())->asItem());
            }
        }
        $this->invMenu->setName(TextFormat::colorize("&r&l&dAbility Spawner &r&7 Generator"));

        $this->invMenu->setListener(function(InvMenuTransaction $transaction) use ($inventory) : InvMenuTransactionResult {

            $player = $transaction->getPlayer();

            switch($transaction->getItemClicked()->getTypeId()){
                case VanillaItems::MINECART()->getTypeId():
                    if(count($contents = $this->contents) === 0){
                        $player->sendMessage(TextFormat::colorize("&cThis generator's storage is empty!"));
                        return $transaction->discard();
                    }
                    $this->contents = [];

                    foreach($contents as $item){
                        if(!$player->getInventory()->canAddItem($item)){
                            $player->getWorld()->dropItem($player->getLocation()->add(0, 1, 0), $item);
                            continue;
                        }
                        $player->getInventory()->addItem($item);
                        $player->getNetworkSession()->sendDataPacket(Utils::playSound($player->getPosition(), "random.orb"));

                        $inventory->setItem(11, VanillaItems::MINECART()->setCustomName(TextFormat::colorize("&r&l&6Storage"))->setLore([0 => "", 1 => TextFormat::colorize("&r&cEmpty ..."), 2 => "", 3 => TextFormat::colorize("&r&eClick to collect storage")]));
                    }
                    break;
                case VanillaItems::VILLAGER_SPAWN_EGG()->getTypeId():
                    $this->flagForDespawn();

                    $player->removeCurrentWindow();
                    $player->getInventory()->addItem(AbilityMain::getInstance()->getSpawnerItem()->setCount(1));
                break;
            }

            return $transaction->discard();
        });
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    protected function initEntity(CompoundTag $nbt) : void {

        /**
         * @internal
        $inventory = $nbt->getTag("Contents");
        if($inventory !== null){
            $contents = [];
            foreach($inventory as $item){
                $contents[$item->getByte("Slot")] = Item::nbtDeserialize($item);
            }
            $this->contents = $contents;
        }*/

        $this->updateTime = $nbt->getInt("updateTime", 600);
        $this->respawnTime = $nbt->getInt("respawnTime", 600);

        $this->isDeath = $nbt->getByte("isDeath", 0) !== 0;

        if($this->isDeath()){
            $this->startRespawnTask($this->respawnTime);
        }else{
            $this->startUpdaterTask();
        }
        parent::initEntity($nbt);
    }

    /**
     * @return CompoundTag
     */
    public function saveNBT() : CompoundTag {
        $nbt = parent::saveNBT();

        $nbt->setInt("updateTime", $this->updateTime);
        $nbt->setInt("respawnTime", $this->respawnTime);

        $nbt->setByte("isDeath", $this->isDeath ? 1 : 0);

        /**
         * @internal
        if(count($contents = $this->contents) !== 0){
            /** @var array<int, CompoundTag> $nbtItems *
            $nbtItems = [];
            foreach($contents as $slot => $item){
                $nbtItems[] = $item->nbtSerialize($slot);
            }
            $nbt->setTag("Contents", new ListTag($nbtItems, NBT::TAG_Compound));
        }*/

        return $nbt;
    }

    /**
     * @param Player $player
     * @param Vector3 $clickPos
     * @return bool
     */
    public function onInteract(Player $player, Vector3 $clickPos) : bool {

        $this->sendMenu($player);

        return true;
    }

    /**
     * @param Player $player
     * @return void
     */
    protected function sendMenu(Player $player) : void {
        if($this->isDeath()){
            return;
        }
        $this->invMenu->send($player);
    }

    /**
     * @param EntityDamageEvent $source
     * @return void
     */
    public function attack(EntityDamageEvent $source) : void {
        if($this->isDeath()){
            return;
        }
        if($this->getHealth() <= $source->getFinalDamage()){
            $this->setDeath(true);
            $this->startRespawnTask();

            $this->setSkin(AbilityMain::getInstance()->getInvisibleSkin());
            $this->sendSkin();
            return;
        }
        if($this->isAlive()){
            $this->doHitAnimation();
        }
        $this->setHealth($this->getHealth() - $source->getFinalDamage());
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick) : bool{
        return $this->entityBaseTick($currentTick - $this->lastUpdate);
    }

    /**
     * @param int $tickDiff
     * @return bool
     */
    protected function entityBaseTick(int $tickDiff = 1) : bool {
        if($this->closed){
            return false;
        }
        if(AbilityMain::getInstance()->shouldRotate()){
            $this->rotation();
        }
        return parent::entityBaseTick($tickDiff);
    }

    /**
     * @return void
     */
    protected function rotation() : void {
        if($this->isDeath()){
            return;
        }
        foreach($this->getWorld()->getNearbyEntities($this->getBoundingBox()->expandedCopy(5, 5, 5), $this) as $player) {
            if($player instanceof Player){
                $xdiff = $player->getPosition()->x - $this->getPosition()->x;
                $zdiff = $player->getPosition()->z - $this->getPosition()->z;
                $angle = atan2($zdiff, $xdiff);
                $yaw = (($angle * 180) / M_PI) - 90;
                $ydiff = $player->getPosition()->y - $this->getPosition()->y;
                $v = new Vector2($this->getPosition()->x, $this->getPosition()->z);
                $dist = $v->distance(new Vector2($player->getPosition()->x, $player->getPosition()->z));
                $angle = atan2($dist, $ydiff);
                $pitch = (($angle * 180) / M_PI) - 90;
                $pk = new MovePlayerPacket();
                $pk->actorRuntimeId = $this->getId();
                $pk->position = $this->getPosition()->asVector3()->add(0, $this->getEyeHeight(), 0);
                $pk->yaw = $yaw;
                $pk->pitch = $pitch;
                $pk->headYaw = $yaw;
                $pk->onGround = $this->onGround;
                $player->getNetworkSession()->sendDataPacket($pk);
            }
        }
    }
}

?>