<?php

namespace abilitygenerator;

use abilitygenerator\entity\NPC;
use abilitygenerator\utils\NBT;

use pocketmine\item\VanillaItems;

use pocketmine\entity\Location;
use pocketmine\event\Listener;

use pocketmine\event\player\PlayerInteractEvent;

class MainListener implements Listener {

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();

        if($item->equals(AbilityMain::getInstance()->getSpawnerItem())){
            $event->cancel();

            $abilitySpawner = new NPC(Location::fromObject($block->getPosition()->add(0.5, 1, 0.5), $player->getWorld()), AbilityMain::getInstance()->getSkin(), NBT::createBaseNBT($block->getPosition()->x, $block->getPosition()->y, $block->getPosition()->z));
            $abilitySpawner->spawnToAll();

            $player->getInventory()->setItemInHand($item->getCount() > 1 ? $item->setCount($item->getCount() - 1) : VanillaItems::AIR());
        }
    }
}

?>