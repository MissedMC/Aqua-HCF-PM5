<?php

namespace Darlexx\ClearLagg\Commands;

use Darlexx\ClearLagg\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Item;
use pocketmine\lang\translatable\TranslationContainer;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class Forceclear extends Command
{

    public function __construct(string $name)
    {
        parent::__construct($name);
        $this->setDescription("Clears all item entities");
        $this->setPermission("clearop.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if ($sender instanceof Player) {
            if ($sender->hasPermission("clearop.admin")) {
                $entityCount = 0;
                foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
                    foreach ($world->getEntities() as $entity) {
                        if ($entity instanceof ItemEntity) {
                            ++$entityCount;
                            $entity->flagForDespawn();
                        }
                    }
                }
                $config = new Config(Main::getInstance()->getDataFolder() . "config.yml", Config::YAML);
                $message = str_replace("{player}", $sender->getName(), $config->get("forceclear"));
                Server::getInstance()->broadcastMessage($message);
            } else {
                $sender->sendMessage("§f[§l§4ERROR§r§f]: You don't have permission to execute this command");
            }
        } else {
            $sender->sendMessage("§f[§l§5ERROR§r§f]: You cannot execute this command from the console");
        }
        return true;
    }
}
