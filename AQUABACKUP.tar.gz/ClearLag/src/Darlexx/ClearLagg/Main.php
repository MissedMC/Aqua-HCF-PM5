<?php

namespace Darlexx\ClearLagg;

use Darlexx\ClearLagg\Task\ClearLaggTask;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener
{

    /**
     * @var Main|null
     */
    private static $instance;

    public function onLoad(): void
    {
        self::$instance = $this;
    }

    public function onEnable(): void
    {
        $this->getLogger()->info("§f[§l§4ClearLagg§r§f]: Activo");
        $this->saveResource("config.yml");

        $this->getServer()->getCommandMap()->registerAll("AllCommands", [
            new Commands\Forceclear(name: "clearop")
        ]);

        $this->getScheduler()->scheduleRepeatingTask(new ClearLaggTask(), 20);
    }

    public static function getInstance(): ?self
    {
        return self::$instance;
    }
}
