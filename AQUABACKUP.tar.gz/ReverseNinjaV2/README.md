# PartnerItemsPM5
Partner Items for an HCF server written in PHP for Pocketmine API 5
