<?php

declare(strict_types=1);

namespace frostcheat\bounty\bounty\command\subcommand;

use frostcheat\bounty\bounty\command\BountySubCommand;
use hcf\player\Player;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\item\VanillaItems;

class TrackerSubCommand implements BountySubCommand
{

    /**
     * @param CommandSender $sender
     * @param array $args
     */
    public function execute(CommandSender $sender, array $args): void
    {
        if (!$sender instanceof Player)
            return;

        if (count($args) < 1) {
            if ($sender->getSession()->getBalance() >= 10000) {
                $item = VanillaItems::COMPASS();
                $item->setCustomName(TextFormat::colorize("&l&cTracker"));
                $namedtag = $item->getNamedTag();
                $namedtag->setString('tracker_item', "tracker_item");
                $item->setNamedTag($namedtag);
                $item->setCount(1);
                $sender->getSession()->setBalance($sender->getSession()->getBalance() - 10000);
                $sender->getInventory()->addItem($item);
            } else $sender->sendMessage(TextFormat::colorize("&cNo tienes dinero suficiente &7($10.000)"));
            return;
        }
    }
}