A Lootbox plugin for your hcf server.

# Commands
- /lootbox setitems - (Set items in lootbox)
- /lootbox give player|all {amount} - (Give partner packages)

# Permissions
- lootbox.command

# Features
- Animation in reward
- Autosave of items
