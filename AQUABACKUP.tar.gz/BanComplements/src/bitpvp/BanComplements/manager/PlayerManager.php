<?php

namespace bitpvp\BanComplements\manager;

use JsonException;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use bitpvp\BanComplements\Loader;

class PlayerManager {

    /**
     * @throws JsonException
     */
    public static function registerPlayer(Player $player): void {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players.json", Config::JSON);
        $file->set($player->getName(), [
            "address" => $player->getNetworkSession()->getIp(),
            "xuid" => $player->getXuid(),
            "first-join" => date("d/m/y H:i:s"),
        ]);
        $file->save();
    }

    public static function getPlayer(string $name)
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players.json", Config::JSON);
        return $file->get($name);
    }

    public static function isRegistered(string $player): bool {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players.json", Config::JSON);
        if ($file->exists($player)) {
            return true;
        }
        return false;
    }

    /**
     * @throws JsonException
     */
    public static function addBan(string $playerName, string $staff, string $reason): void {
        $date = date("d/m/y H:i:s");
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-banned.json", Config::JSON);
        $file->set($playerName, ["staff" => $staff, "reason" => $reason, "date" => $date]);
        $file->save();
    }

    /**
     * @throws JsonException
     */
    public static function removeBan(string $playerName): void {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-banned.json", Config::JSON);
        $file->remove($playerName);
        $file->save();
    }

    /**
     * @throws JsonException
     */
    public static function addIPBan(string $ip, string $banned, string $staff, string $reason): void {
        $date = date("d/m/y H:i:s");
        $file = new Config(Loader::getInstance()->getDataFolder() . "ips-banned.json", Config::JSON);
        $file->set($ip, ["banned" => $banned, "staff" => $staff, "reason" => $reason, "date" => $date]);
        $file->save();
    }

    /**
     * @throws JsonException
     */
    public static function removeIPBan(string $ip): void {
        $file = new Config(Loader::getInstance()->getDataFolder() . "ips-banned.json", Config::JSON);
        $file->remove($ip);
        $file->save();
    }

    public static function isPermanentIPBanned(string $ip): bool
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "ips-banned.json", Config::JSON);
        if ($file->exists($ip)) {
            return true;
        }
        return false;
    }

    public static function getPermanentIPBan(string $ip)
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "ips-banned.json", Config::JSON);
        return $file->get($ip);
    }

    public static function isPermanentBanned(string $playerName): bool
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-banned.json", Config::JSON);
        if ($file->exists($playerName)) {
            return true;
        }
        return false;
    }

    public static function getPermanentBan(string $player)
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-banned.json", Config::JSON);
        return $file->get($player);
    }

    /**
     * @throws JsonException
     */
    public static function addMute(string $playerName, string $staff, string $reason, $time = null): void
    {
        $date = date("d/m/y H:i:s");
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-mute.json", Config::JSON);
        $file->set($playerName, ["staff" => $staff, "reason" => $reason, "date" => $date, "time" => $time]);
        $file->save();
    }

    /**
     * @throws JsonException
     */
    public static function removeMute(string $playerName): void{
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-mute.json", Config::JSON);
        $file->remove($playerName);
        $file->save();
    }

    public static function isMuted(string $playerName): bool
    {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-mute.json", Config::JSON);
        if ($file->exists($playerName)) {
            return true;
        }
        return false;
    }

    public static function getMute(string $player) {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-mute.json", Config::JSON);
        return $file->get($player);
    }

    public static function getAllPermanentBanneds(): array {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-banned.json", Config::JSON);
        return $file->getAll(true);
    }

    public static function getAllPermanentIPBanneds(): array {
        $file = new Config(Loader::getInstance()->getDataFolder() . "ips-banned.json", Config::JSON);
        return $file->getAll(true);
    }

    public static function getAllMuted(): array {
        $file = new Config(Loader::getInstance()->getDataFolder() . "players-mute.json", Config::JSON);
        return $file->getAll(true);
    }
}