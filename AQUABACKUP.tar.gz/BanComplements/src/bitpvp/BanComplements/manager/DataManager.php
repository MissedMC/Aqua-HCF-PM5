<?php

namespace bitpvp\BanComplements\manager;

use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use bitpvp\BanComplements\Loader;

class DataManager {

    use SingletonTrait;

    private Config $config;

    public function __construct()
    {
        self::setInstance($this);
        $this->config = new Config(Loader::getInstance()->getDataFolder() . "config.yml", Config::YAML);
    }

    public function getConfig(string $config) {
        return $this->config->get($config);
    }

    public static function sendMessage(string $message): int {
        return Server::getInstance()->broadcastMessage($message);
    }
}