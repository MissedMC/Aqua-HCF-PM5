<?php

namespace bitpvp\BanComplements\logs;

use CortexPE\DiscordWebhookAPI\Embed;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use pocketmine\utils\SingletonTrait;
use bitpvp\BanComplements\manager\DataManager;

class DiscordLogs {

    use SingletonTrait;

    public function __construct()
    {
        self::setInstance($this);
    }

    public function sendBanLog(string $banned, string $staff, string $reason): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER BANNED");
        $embed->addField("Banned:", $banned);
        $embed->addField("Staff:", $staff);
        $embed->addField("Reason:", $reason);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendUnBanLog(string $unbanned, string $staff): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER UNBANNED");
        $embed->addField("Unbanned:", $unbanned);
        $embed->addField("Staff:", $staff);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendBanIPLog(string $ip, string $banned, string $staff, string $reason): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER IP-BANNED");
        $embed->addField("IP:", $ip);
        $embed->addField("IP-Banned:", $banned);
        $embed->addField("Staff:", $staff);
        $embed->addField("Reason:", $reason);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendUnBanIPLog(string $ip, string $unbanned, string $staff): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER IP-UNBANNED");
        $embed->addField("IP:", $ip);
        $embed->addField("IP-UnBanned:", $unbanned);
        $embed->addField("Staff:", $staff);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendReportLog(string $sender, string $reported, string $reason): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER REPORTED");
        $embed->addField("Sender:", $sender);
        $embed->addField("Reported:", $reported);
        $embed->addField("Reason:", $reason);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendMuteLogs(string $muted, string $staff, string $reason, string $time): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER MUTED");
        $embed->addField("Muted:", $muted);
        $embed->addField("Staff:", $staff);
        $embed->addField("Reason:", $reason);
        $embed->addField("Time:", $time);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendUnMuteLogs(string $unmuted, string $staff): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER MUTED");
        $embed->addField("UnMuted:", $unmuted);
        $embed->addField("Staff:", $staff);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }

    public function sendKickLog(string $kicked, string $staff, string $reason): void {
        $webhook = new Webhook(DataManager::getInstance()->getConfig("logs"));
        $message = new Message();
        $embed = new Embed();
        $embed->setTitle("PLAYER KICKED");
        $embed->addField("Kicked:", $kicked);
        $embed->addField("Staff:", $staff);
        $embed->addField("Reason:", $reason);
        $embed->setColor(hexdec('515151'));
        $message->setContent("<@&1094003237822156848>");
        $message->addEmbed($embed);
        $webhook->send($message);
    }
}