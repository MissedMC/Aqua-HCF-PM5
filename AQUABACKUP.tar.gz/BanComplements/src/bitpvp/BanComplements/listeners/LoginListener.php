<?php

namespace bitpvp\BanComplements\listeners;

use JsonException;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class LoginListener implements Listener {

    public function onPlayerLogin(PlayerLoginEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        $ip = $player->getNetworkSession()->getIp();

        if(PlayerManager::isPermanentBanned($name)){
            $msg = DataManager::getInstance()->getConfig("permanently-ban-kick");
            $player->kick(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{date}'], [PlayerManager::getPermanentBan($name)['staff'], PlayerManager::getPermanentBan($name)['reason'], PlayerManager::getPermanentBan($name)['date']], $msg)));
            return;
        }

        if(PlayerManager::isPermanentIPBanned($ip)){
            $msg = DataManager::getInstance()->getConfig("permanently-ban-ip-kick");
            $player->kick(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{date}'], [PlayerManager::getPermanentIPBan($ip)['staff'], PlayerManager::getPermanentIPBan($ip)['reason'], PlayerManager::getPermanentIPBan($ip)['date']], $msg)));
        }
    }

    /**
     * @throws JsonException
     */
    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $ip = $player->getNetworkSession()->getIp();

        if(PlayerManager::isRegistered($player->getName())){
            if(PlayerManager::getPlayer($player->getName())["address"] !== $ip){
                PlayerManager::registerPlayer($player);
            }
        }

        if(!PlayerManager::isRegistered($player->getName())){
            PlayerManager::registerPlayer($player);
        }
    }
}
