<?php


namespace bitpvp\BanComplements\listeners;

use JsonException;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;
use bitpvp\BanComplements\manager\TimeManager;

class ChatListener implements Listener {

    /**
     * @throws JsonException
     */
    public function onPlayerChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();
        if (PlayerManager::isMuted($name)) {
            $time = PlayerManager::getMute($player->getName())['time'];
            $left = TimeManager::getTimeLeft($time);

            if ($left <= 1) {
                PlayerManager::removeMute($name);
                return;
            }
            $reason = PlayerManager::getMute($player->getName())['reason'];
            $player->sendMessage(TextFormat::colorize(str_replace(['{reason}'], [$reason], DataManager::getInstance()->getConfig("temporarily-mute"))));
            $event->cancel();
        }
    }
}