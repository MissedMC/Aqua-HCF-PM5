<?php

namespace bitpvp\BanComplements;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use bitpvp\BanComplements\commands\BanCommand;
use bitpvp\BanComplements\commands\BanIpCommand;
use bitpvp\BanComplements\commands\BanIPListCommand;
use bitpvp\BanComplements\commands\BanListCommand;
use bitpvp\BanComplements\commands\KickCommand;
use bitpvp\BanComplements\commands\MuteCommand;
use bitpvp\BanComplements\commands\MuteListCommand;
use bitpvp\BanComplements\commands\ReportCommand;
use bitpvp\BanComplements\commands\UnBanCommand;
use bitpvp\BanComplements\commands\UnBanIPCommand;
use bitpvp\BanComplements\commands\UnMuteCommand;
use bitpvp\BanComplements\listeners\ChatListener;
use bitpvp\BanComplements\listeners\LoginListener;

class Loader extends PluginBase {
    use SingletonTrait;

    protected function onEnable(): void
    {
        self::setInstance($this);

        $this->saveDefaultConfig();

        $this->unregisterCommand(["ban", "banlist", "ban-ip", "unban", "unban-ip", "kick"]);

        $this->getServer()->getCommandMap()->registerAll("BanComplements", [
            new BanCommand(),
            new KickCommand(),
            new UnBanCommand(),
            new MuteCommand(),
            new BanIpCommand(),
            new UnBanIPCommand(),
            new BanListCommand(),
            new BanIPListCommand(),
            new MuteListCommand(),
            new ReportCommand(),
            new UnMuteCommand()
        ]);

        $this->registerListener([
            new LoginListener(),
            new ChatListener()
        ]);
    }

    public function registerListener(array $listeners): void
    {
        foreach ($listeners as $listener){
            $this->getServer()->getPluginManager()->registerEvents($listener, $this);
        }
    }

    public function unregisterCommand(array $commandName) : void{
        $commandMap = $this->getServer()->getCommandMap();
        foreach ($commandName as $cmd) {
            if(($cmd = $commandMap->getCommand($cmd)) !== null){
                $commandMap->unregister($cmd);
            }
        }
    }
}