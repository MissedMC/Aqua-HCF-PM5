<?php

namespace bitpvp\BanComplements\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;

class KickCommand extends Command {

    public function __construct()
    {
        parent::__construct("kick", "", "");
        $this->setPermission("kick.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));

    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        if(count($args) < 2){
            $sender->sendMessage(TextFormat::colorize("&cType: /kick [player] [reason]"));
            return;
        }
        $victim = Server::getInstance()->getPlayerByPrefix($args[0]);

        if(!$victim instanceof Player){
            $sender->sendMessage(TextFormat::colorize("&cPlayer is offline."));
            return;
        }

        array_shift($args);
        $reason = implode(" ", $args);
        DiscordLogs::getInstance()->sendKickLog($victim->getName(), $sender->getName(), $reason);
        DataManager::sendMessage(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{player}'], [$sender->getName(), $reason, $victim->getName()], DataManager::getInstance()->getConfig('kick-message-now'))));
        $victim->kick(TextFormat::colorize(str_replace(['{staff}', '{reason}'], [$sender->getName(), $reason], DataManager::getInstance()->getConfig('kick-message'))));

    }
}
