<?php

namespace bitpvp\BanComplements\commands;

use JsonException;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class BanIpCommand extends Command {

    public function __construct()
    {
        parent::__construct("ban-ip", "", "");
        $this->setPermission("banip.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    /**
     * @throws JsonException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        if(count($args) < 2){
            $sender->sendMessage(TextFormat::colorize("&cType: /ban-ip [player] [reason]"));
            return;
        }

        $victim = $args[0];

       if(!PlayerManager::isRegistered($victim)){
           $sender->sendMessage(TextFormat::colorize("&cThis player is not registered"));
           return;
       }

       $ip = PlayerManager::getPlayer($args[0])["address"];

       if(PlayerManager::isPermanentIPBanned($ip)){
           $sender->sendMessage(TextFormat::colorize("&cPlayer is already ip-banned"));
           return;
       }
       array_shift($args);
       $reason = implode(" ", $args);

       PlayerManager::addIPBan($ip, $victim, $sender->getName(), $reason);
       DiscordLogs::getInstance()->sendBanIPLog($ip, $victim, $sender->getName(), $reason);
       DataManager::sendMessage(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{banned}'], [$sender->getName(), $reason, $victim], DataManager::getInstance()->getConfig('permanently-ban-ip-kick-now'))));;

       if(($xd = Server::getInstance()->getPlayerExact($victim)) instanceof Player){
           $msg = DataManager::getInstance()->getConfig("permanently-ban-ip-kick");
           $xd->kick(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{date}'], [$sender->getName(), $reason, PlayerManager::getPermanentIPBan($ip)['date']], $msg)));
       }
    }
}
