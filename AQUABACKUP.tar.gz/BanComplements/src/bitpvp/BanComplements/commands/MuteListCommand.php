<?php

namespace bitpvp\BanComplements\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class MuteListCommand extends Command {

    public function __construct()
    {
        parent::__construct("mutelist", "", "");
        $this->setPermission("mutelist.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        $muteds = PlayerManager::getAllMuted();

        if(count($muteds) <= 0) {
            $sender->sendMessage(TextFormat::colorize("&cThere is no muted player"));
            return;
        }

        $sender->sendMessage(TextFormat::colorize("&e&lAll MUTEDS Player's"));
        foreach ($muteds as $muted) {
            $date = PlayerManager::getMute($muted)['date'];
            $reason = PlayerManager::getMute($muted)['reason'];
            $sender->sendMessage(TextFormat::colorize("&e$muted&7 muted for &l$reason&r&7 on &l$date&r&7."));
        }
        $sender->sendMessage(TextFormat::colorize("&8There are a total &l".count($muteds)."&r&8 of muted players."));
    }
}