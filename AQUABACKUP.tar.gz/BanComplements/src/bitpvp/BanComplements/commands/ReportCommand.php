<?php

namespace bitpvp\BanComplements\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;

class ReportCommand extends Command {

    public function __construct()
    {
        parent::__construct("report", "", "");
        $this->setPermission("report.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof Player) return;

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        if(count($args) < 2){
            $sender->sendMessage(TextFormat::colorize("&cType: /report [player] [reason]"));
            return;
        }

        $victim = Server::getInstance()->getPlayerByPrefix($args[0]);

        if(!$victim instanceof Player){
            $sender->sendMessage(TextFormat::colorize("&cThis player is offline."));
            return;
        }

        array_shift($args);
        $reason = implode(" ", $args);

        $sender->sendMessage(TextFormat::colorize("&cThe staff team just received the report, wait for them to see it."));
        DiscordLogs::getInstance()->sendReportLog($sender->getName(), $victim->getName(), $reason);
        foreach (Server::getInstance()->getOnlinePlayers() as $online) {
            if($online->hasPermission("report.notify")){
                $online->sendMessage(TextFormat::colorize("&e&lREPORT&r&e by &7{$sender->getName()}\n\n&cPlayer&7:&e {$victim->getName()}\n&cReason&7:&e $reason"));
            }
        }
    }
}