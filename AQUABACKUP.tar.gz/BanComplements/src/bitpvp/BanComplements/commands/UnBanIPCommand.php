<?php

namespace bitpvp\BanComplements\commands;

use JsonException;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class UnBanIPCommand extends Command {

    public function __construct()
    {
        parent::__construct("unban-ip", "", "");
        $this->setPermission("unbanip.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    /**
     * @throws JsonException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {


        if(count($args) < 1){
            $sender->sendMessage(TextFormat::colorize("&cType: /unban-ip [player]"));
            return;
        }

        if(!PlayerManager::isRegistered($args[0])){
            $sender->sendMessage(TextFormat::colorize("&cThis player is not registered"));
            return;
        }

        $victim = PlayerManager::getPlayer($args[0]);
        $ip = $victim["address"];

        if(PlayerManager::isPermanentIPBanned($ip)){
            PlayerManager::removeIPBan($ip);
            DiscordLogs::getInstance()->sendUnBanIPLog($ip, $victim, $sender->getName());
            DataManager::sendMessage(TextFormat::colorize(str_replace(['{staff}', '{unbanned}'], [$sender->getName(), $victim], DataManager::getInstance()->getConfig("unban-ip-message-now"))));
            return;
        }

        $sender->sendMessage(TextFormat::colorize("&cThis player is not ip-banned."));
    }
}