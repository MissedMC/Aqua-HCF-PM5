<?php

namespace bitpvp\BanComplements\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class BanIPListCommand extends Command {

    public function __construct()
    {
        parent::__construct("banlist-ip", "", "");
        $this->setPermission("banlist.ip.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        $banneds = PlayerManager::getAllPermanentIPBanneds();

        if(count($banneds) <= 0) {
            $sender->sendMessage(TextFormat::colorize("&cThere is no ip-banned player"));
            return;
        }

        $sender->sendMessage(TextFormat::colorize("&e&lAll IP-BANNEDS Player's"));
        foreach ($banneds as $banned) {
            $date = PlayerManager::getPermanentIPBan($banned)['date'];
            $reason = PlayerManager::getPermanentIPBan($banned)['reason'];
            $name = PlayerManager::getPermanentIPBan($banned)['banned'];
            $sender->sendMessage(TextFormat::colorize("&e$name &8($banned) &7ip-banned for &l$reason&r&7 on &l$date&r&7."));
        }
        $sender->sendMessage(TextFormat::colorize("&8There are a total &l".count($banneds)."&r&8 of ip-banned players."));
    }
}