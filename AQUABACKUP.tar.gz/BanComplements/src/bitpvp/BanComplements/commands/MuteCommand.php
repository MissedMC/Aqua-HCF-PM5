<?php

namespace bitpvp\BanComplements\commands;

use JsonException;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;
use bitpvp\BanComplements\manager\TimeManager;

class MuteCommand extends Command {

    public function __construct()
    {
        parent::__construct("mute", "", "");
        $this->setPermission("mute.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    /**
     * @throws JsonException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        if(count($args) < 3){
            $sender->sendMessage(TextFormat::colorize("&cType: /mute [player] [time] [reason]"));
            return;
        }

        if(!is_numeric($args[1][0]) || !in_array(TimeManager::intToString($args[1]), TimeManager::VALID_FORMATS)){
            $sender->sendMessage(TextFormat::colorize("&cPlease enter a valid time format."));
            return;
        }

        $victim = $args[0];

        if(PlayerManager::isMuted($victim)){
            $sender->sendMessage(TextFormat::colorize("&cPlayer is already muted."));
            return;
        }

        $time = TimeManager::getFormatTime(TimeManager::stringToInt($args[1]), $args[1]);
        array_shift($args);
        array_shift($args);
        $reason = implode(" ", $args);
        PlayerManager::addMute($victim, $sender->getName(), $reason, $time);
        DiscordLogs::getInstance()->sendMuteLogs($victim, $sender->getName(), $reason, TimeManager::getTimeLeft($time));
        DataManager::sendMessage(TextFormat::colorize(str_replace(['{staff}', '{player}', '{reason}', '{date}'], [$sender->getName(), $victim, $reason, PlayerManager::getMute($victim)["date"]], DataManager::getInstance()->getConfig('temporarily-mute-now'))));

        if(($victim = Server::getInstance()->getPlayerExact($victim)) instanceof Player){
            $victim->sendMessage(TextFormat::colorize(str_replace('{reason}', $reason, DataManager::getInstance()->getConfig("temporarily-mute"))));
        }
    }
}