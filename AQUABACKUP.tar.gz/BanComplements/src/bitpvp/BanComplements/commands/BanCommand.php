<?php

namespace bitpvp\BanComplements\commands;

use JsonException;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use bitpvp\BanComplements\logs\DiscordLogs;
use bitpvp\BanComplements\manager\DataManager;
use bitpvp\BanComplements\manager\PlayerManager;

class BanCommand extends Command {

    public function __construct()
    {
        parent::__construct("ban", "", "");
        $this->setPermission("ban.command");
        $this->setPermissionMessage(TextFormat::colorize("&cYou do not have permissions to use this."));
    }

    /**
     * @throws JsonException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {

        if(!$this->testPermission($sender)) {
            $sender->sendMessage($this->getPermissionMessage());
            return;
        }

        if(count($args) < 2){
            $sender->sendMessage(TextFormat::colorize("&cType: /ban [player] [reason]"));
            return;
        }
        $victim = $args[0];

        if(PlayerManager::isPermanentBanned($victim)){
            $sender->sendMessage(TextFormat::colorize("&cPlayer is already banned"));
            return;
        }
        array_shift($args);
        $reason = implode(" ", $args);

        PlayerManager::addBan($victim, $sender->getName(), $reason);
        DiscordLogs::getInstance()->sendBanLog($victim, $sender->getName(), $reason);
        DataManager::sendMessage(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{banned}'], [$sender->getName(), $reason, $victim], DataManager::getInstance()->getConfig('permanently-ban-kick-now'))));

        if(($xd = Server::getInstance()->getPlayerExact($victim)) instanceof Player){
            $msg = DataManager::getInstance()->getConfig("permanently-ban-kick");
            $xd->kick(TextFormat::colorize(str_replace(['{staff}', '{reason}', '{date}'], [$sender->getName(), $reason, PlayerManager::getPermanentBan($victim)['date']], $msg)));
        }
    }
}
