# **Repair!**


_**Comandos con Permisos:**_


 - fix hand:
    permiso: fix-hand.command.use
 - fix all:
    permiso: fix-all.command.use
 - fix all (player):
    permiso: fix-all-others.command.use
 - fix:
    permiso: fix.cmd

###### **tiene de alias como "repair y fix", todos los mensajes configurables en "config.yml"**
