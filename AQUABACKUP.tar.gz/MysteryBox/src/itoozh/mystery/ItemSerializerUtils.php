<?php

namespace itoozh\mystery;

use InvalidArgumentException;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\TreeRoot;
use function count;

final class ItemSerializerUtils{

    private const TAG_NAME = "items";

    /**
     * @param array<Item> $items
     * @return string
     */
    public static function serialize(array $items) : string{
        if(count($items) === 0){
            return "";
        }

        $contents_tag = [];
        foreach($items as $item){
            $contents_tag[] = $item->nbtSerialize();
        }
        return (new BigEndianNbtSerializer())->write(new TreeRoot(CompoundTag::create()->setTag(self::TAG_NAME, new ListTag($contents_tag, NBT::TAG_Compound))));
    }

    /**
     * @param string $string
     * @return array<int, Item>
     */
    public static function deSerialize(string $string) : array{
        if($string === ""){
            return [];
        }

        $tag = (new BigEndianNbtSerializer())->read($string)->mustGetCompoundTag()->getListTag(self::TAG_NAME) ?? throw new InvalidArgumentException("Invalid serialized string specified");

        $items = [];
        /** @var CompoundTag $value */
        foreach($tag as $value){
            try{
                $item = Item::nbtDeserialize($value);
            }catch(SavedDataLoadingException){
                continue;
            }
            $items[] = $item;
        }
        return $items;
    }
}