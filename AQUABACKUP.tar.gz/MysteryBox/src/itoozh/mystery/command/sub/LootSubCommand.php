<?php

namespace itoozh\mystery\command\sub;

use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\exception\ArgumentOrderException;
use itoozh\mystery\command\argument\StringListArgument;
use itoozh\mystery\Main;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;

class LootSubCommand extends BaseSubCommand
{
    public function __construct(PluginBase $plugin, string $name, string $description = "", array $aliases = [])
    {
        parent::__construct($plugin, $name, $description, $aliases);
    }

    /**
     * @throws ArgumentOrderException
     */
    protected function prepare(): void
    {
        $this->registerArgument(0, new StringListArgument('loot', ['common', 'exclusive']));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) return;
        $loot = $args['loot'];
        if ($loot === 'common') {
            $this->openCommonLootMenu($sender);
        } elseif ($loot === 'exclusive') {
            $this->openExclusiveLootMenu($sender);
        }
    }

    public function openCommonLootMenu(Player $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        foreach (Main::getCommonLoot() as $item){
            $menu->getInventory()->addItem($item);
        }
        $menu->setInventoryCloseListener(function (Player $player, $inventory): void {
            $items = [];
            foreach($inventory->getContents() as $slot => $item){
                $items[] = $item;
            };
            Main::setCommonLoot($items);
            $player->sendMessage(Main::$PREFIX . TextFormat::GREEN . 'The content of the mystery box loot common has been edited correctly.');
        });
        $menu->send($player, TextFormat::BLUE . 'Edit the common crate loot');
    }
    public function openExclusiveLootMenu(Player $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        foreach (Main::getExclusiveLoot() as $item){
            $menu->getInventory()->addItem($item);
        }
        $menu->setInventoryCloseListener(function (Player $player, $inventory): void {
            $items = [];
            foreach($inventory->getContents() as $slot => $item){
                $items[] = $item;
            };
            Main::setExclusiveLoot($items);
            $player->sendMessage(Main::$PREFIX . TextFormat::GREEN . 'The content of the mystery box loot exclusive has been edited correctly.');
        });
        $menu->send($player, TextFormat::BLUE . 'Edit the exclusive crate loot');
    }
}