<?php

namespace itoozh\mystery\command\sub;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\BaseSubCommand;
use itoozh\mystery\Main;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class GiveAllSubCommand extends BaseSubCommand
{

    protected function prepare(): void
    {
        $this->registerArgument(0, new IntegerArgument('amount', true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $amount = $args['amount'] ?? 1;
        $item = Main::getMysteryCrateItem($amount);
        foreach ($sender->getServer()->getOnlinePlayers() as $player) {
            if ($player->getInventory()->canAddItem($item)) {
                $player->getInventory()->addItem($item);
            } else {
                $player->dropItem($item);
            }
        }
        $sender->sendMessage(Main::$PREFIX . TextFormat::GREEN . 'Successfully given x' . $amount . ' mystery crates to all online players');
    }
}