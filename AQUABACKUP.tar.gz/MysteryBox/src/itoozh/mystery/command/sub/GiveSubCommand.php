<?php

namespace itoozh\mystery\command\sub;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\BaseSubCommand;
use itoozh\mystery\Main;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class GiveSubCommand extends BaseSubCommand
{

    protected function prepare(): void
    {
        $this->registerArgument(0, new TargetPlayerArgument('player'));
        $this->registerArgument(1, new IntegerArgument('amount', true));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $name = $args['player'] ;
        $amount = $args['amount'] ?? 1;
        $player = Server::getInstance()->getPlayerExact($name);

        if ($player === null) {
            $sender->sendMessage(Main::$PREFIX . TextFormat::RED . $name . " is not online!");
            return;
        }

        $item = Main::getMysteryCrateItem($amount);
        if ($player->getInventory()->canAddItem($item)) {
            $player->getInventory()->addItem($item);
        } else {
            $player->dropItem($item);
        }
        $sender->sendMessage(Main::$PREFIX . TextFormat::GREEN . 'Successfully gave x' . $amount . ' mystery crates to ' . $name);
    }
}