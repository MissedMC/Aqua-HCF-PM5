<?php

namespace itoozh\mystery\command;

use CortexPE\Commando\BaseCommand;
use itoozh\mystery\command\sub\GiveSubCommand;
use itoozh\mystery\command\sub\LootSubCommand;
use itoozh\mystery\command\sub\GiveAllSubCommand;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;

class MysteryCrateCommand extends BaseCommand
{
    public function __construct(Plugin $plugin, string $name, Translatable|string $description = "", array $aliases = [])
    {
        parent::__construct($plugin, $name, $description, $aliases);
        $this->setPermission('use.mystery.crate.command');
    }

    protected function prepare(): void
    {
        $this->registerSubCommand(new LootSubCommand($this->plugin, 'loot'));
        $this->registerSubCommand(new GiveAllSubCommand($this->plugin, 'giveall'));
        $this->registerSubCommand(new GiveSubCommand($this->plugin, 'give'));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $this->sendUsage();
    }
}