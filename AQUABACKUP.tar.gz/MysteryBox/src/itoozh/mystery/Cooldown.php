<?php

namespace itoozh\mystery;

use pocketmine\player\Player;

class Cooldown
{
    // array<UUID, Long>
    /* @var array<string, int> */
    private array $cooldowns;

    public function __construct()
    {
        $this->cooldowns = [];
    }

    public function hasCooldown(Player $player): bool
    {
        if (!isset($this->cooldowns[$player->getName()])) return false;
        return $this->cooldowns[$player->getName()] > time();
    }

    public function applyCooldown(Player $player, int $cooldown): void
    {
        $this->cooldowns[$player->getName()] = time() + $cooldown;
    }

    public function getRemaining(Player $player): string
    {
        return (($this->cooldowns[$player->getName()] ?? 0) - time()) . 's';
    }
}