<?php

namespace itoozh\mystery\task;

use itoozh\mystery\entity\FloatingText;
use itoozh\mystery\entity\ItemEntity;
use itoozh\mystery\Main;
use pocketmine\entity\Entity;
use pocketmine\entity\Location;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\NetworkBroadcastUtils;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\entity\PropertySyncData;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\world\particle\CriticalParticle;
use pocketmine\world\Position;

class AnimationTask extends Task
{
    /** @var ItemEntity[] */
    private array $items;
    private Position $center;
    private float $angle = 0;

    private ?ItemEntity $centerItem;

    private int $tick = 0;
    /** @var FloatingText[] */
    private array $floatingTexts = [];

    private Player $player;

    public function __construct(Position $center, array $items, Player $player)
    {
        $this->player = $player;
        $this->items = $items;
        $this->center = $center;
        $this->centerItem = new ItemEntity(new Location($this->center->x, $this->center->y + 1, $this->center->z, $this->center->world, 0, 0), Main::getRandomExlusiveReward());
        $this->centerItem->spawnToAll();

        $this->floatingTexts[] = new FloatingText(new Location($this->center->x, $this->center->y + 2.5, $this->center->z, $this->center->world, 0, 0), Main::$NAME);
        $this->floatingTexts[] = new FloatingText(new Location($this->center->x, $this->center->y + 2, $this->center->z, $this->center->world, 0, 0), '&3Purchased from &b' . Main::$STORE);

        foreach ($this->floatingTexts as $floatingText) {
            $floatingText->spawnToAll();
        }
    }

    protected bool $running = true;

    private array $uptimes = [];
    /** @var Item[] */
    private array $commonRewards = [];
    /** @var Item[] */
    private array $exclusiveRewards = [];

    public function onRun(): void
    {

        if ($this->running) {
            $centerX = $this->center->getX();
            $centerZ = $this->center->getZ();
            $radius = 3;
            $itemCount = count($this->items);
            /** @var ItemEntity $itemEntity */
            foreach ($this->items as $itemEntity) {
                if ($itemEntity->isClosed()) continue;
                $angle = $this->angle + 2 * M_PI * $itemEntity->getId() / $itemCount;
                $x = $centerX + $radius * cos($angle);
                $z = $centerZ + $radius * sin($angle);
                if ($itemEntity->getLiveTime() > 20) {
                    $itemEntity->setItem(Main::getRandomCommonReward());
                    $itemEntity->setLiveTime(0);
                    $itemEntity->despawnFromAll();
                    $itemEntity->spawnToAll();
                }

                $itemEntity->teleport(new Vector3($x, $this->center->getY() + 1, $z));
                $this->playCriticalParticle(new Position($x, $this->center->getY() + 1, $z, $this->center->getWorld()));
                $this->angle += 0.05;
            }
            if (!$this->centerItem->isClosed()) {
                if ($this->centerItem->getLiveTime() > 20) {
                    $this->centerItem->setItem(Main::getRandomExlusiveReward());
                    $this->centerItem->setLiveTime(0);
                    $this->centerItem->despawnFromAll();
                    $this->centerItem->spawnToAll();
                }
            }
        } else {
            if ($this->tick >= 70) {
                if ($this->centerItem !== null) {
                    if (!$this->centerItem->isClosed()) {
                        $this->playLight($this->centerItem->getLocation());
                        $this->centerItem->flagForDespawn();
                        $this->exclusiveRewards[] = $this->centerItem->getRewardItem();
                        $this->centerItem = null;
                    }
                }
                $dif = 0;
                foreach ($this->items as $index => $itemEntity) {
                    if ($itemEntity->isClosed()) continue;
                    if (!isset($this->uptimes[$index])) {
                        $dif += 7;
                        $this->uptimes[$index] = $dif;
                    }
                    if ($this->tick >= 70 + $this->uptimes[$index]) {
                        $this->playLight($itemEntity->getLocation());
                        $itemEntity->flagForDespawn();
                        $this->commonRewards[] = $itemEntity->getRewardItem();
                        unset($this->items[$index]);
                    }
                }
            }

            if (count($this->items) === 0 && $this->centerItem == null) {
                foreach ($this->floatingTexts as $floatingText) {
                    $floatingText->flagForDespawn();
                }
                $this->giveReward();
                $this->getHandler()->cancel();
            }
        }

        if ($this->tick >= 60)
            $this->running = false;

        $this->tick++;
    }

    public function playCriticalParticle(Position $pos,int $radius = 1): void {
        for ($i = 0; $i < 5; $i++) {
            $randomX = mt_rand(-$radius, $radius);
            $randomY = mt_rand(-$radius, $radius);
            $randomZ = mt_rand(-$radius, $radius);

            $x = $pos->x + $randomX;
            $y = ($pos->y + 1) + $randomY;
            $z =$pos->z + $randomZ;

            $position = new Position($x, $y, $z, $pos->getWorld());
            $particle = new CriticalParticle();

            $pos->getWorld()->addParticle($position, $particle);
        }
    }

    public function playLight(Position $pos): void {
        $pk = new AddActorPacket();
        $pk->actorUniqueId = Entity::nextRuntimeId();
        $pk->actorRuntimeId = 1;
        $pk->position = $pos->asVector3();
        $pk->type = "minecraft:lightning_bolt";
        $pk->yaw = 0;
        $pk->syncedProperties = new PropertySyncData([], []);
        $sound = PlaySoundPacket::create("ambient.weather.thunder", $pos->getX(), $pos->getY(), $pos->getZ(), 1, 1);
        NetworkBroadcastUtils::broadcastPackets($pos->getWorld()->getPlayers(), [$pk, $sound]);
    }

    public function giveReward(): void {
        if (!$this->player->isOnline()) return;

        $colors = [
            TextFormat::DARK_GREEN,
            TextFormat::GREEN,
            TextFormat::YELLOW,
            TextFormat::GOLD,
            TextFormat::RED,
            TextFormat::DARK_RED,
            TextFormat::AQUA,
            TextFormat::DARK_AQUA,
            TextFormat::BLUE,
            TextFormat::DARK_BLUE,
            TextFormat::LIGHT_PURPLE,
            TextFormat::DARK_PURPLE,
        ];

        $msg = [
            '&b--------&3--------&b--------&3--------&b--------',
            '                 &l&bMYSTERY &3BOX&b&r      ',
            '            &7 * ' . Main::$STORE . '&7 * ',
            '  ',
            '&b' . $this->player->getName() . ' &7has opened the following rewards:',
            '  ',
            '&l&aCOMMON&r'
        ];

        foreach ($this->commonRewards as $item) {
            list($color, $count, $msg) = $this->applyFormat($colors, $item, $msg);
        }
        $msg[] = ' ';
        $msg[] = '&l&cEXCLUSIVE&r';

        foreach ($this->exclusiveRewards as $item) {
            list($color, $count, $msg) = $this->applyFormat($colors, $item, $msg);
        }
        $msg[] = ' ';
        $msg[] = '&b--------&3--------&b--------&3--------&b--------';
        Server::getInstance()->broadcastMessage(TextFormat::colorize(implode("\n", $msg)));
    }

    /**
     * @param array $colors
     * @param Item $item
     * @param array $msg
     * @return array
     */
    public function applyFormat(array $colors, Item $item, array $msg): array
    {
        $color = $colors[array_rand($colors)];
        $count = $item->getCount() > 1 ? $item->getCount() . ' ' : '';
        $msg[] = TextFormat::GRAY . ' * ' . $color . $count . ($item->hasCustomName() ? TextFormat::clean($item->getCustomName()) : $item->getName()) . '&r';
        if ($this->player->getInventory()->canAddItem($item)) {
            $this->player->getInventory()->addItem($item);
        } else {
            $this->player->dropItem($item);
        }
        return array($color, $count, $msg);
    }
}