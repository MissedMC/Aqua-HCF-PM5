<?php

namespace itoozh\mystery;

use hcf\HCFLoader;

use CortexPE\Commando\exception\HookAlreadyRegistered;
use CortexPE\Commando\PacketHooker;
use itoozh\mystery\command\MysteryCrateCommand;
use itoozh\mystery\entity\FloatingText;
use itoozh\mystery\entity\ItemEntity;
use itoozh\mystery\task\AnimationTask;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\entity\EntityDataHelper as Helper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use hcf\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use pocketmine\world\World;
use pocketmine\event\player\PlayerCreationEvent;

class Main extends PluginBase implements Listener
{
    private Cooldown $openCooldown;
    /* @var Item[] */
    private static array $commonLoot = [];
    /* @var Item[] */
    private static array $exclusiveLoot = [];

    public static string $NAME;
    public static string $STORE;
    public static string $PREFIX;

    /**
     * @throws HookAlreadyRegistered
     */
    protected function onEnable(): void
    {
        if(!PacketHooker::isRegistered())
            PacketHooker::register($this);
        if (!InvMenuHandler::isRegistered())
            InvMenuHandler::register($this);

        $this->openCooldown = new Cooldown();
        $this->saveDefaultConfig();

        self::$NAME = TextFormat::colorize($this->getConfig()->get('name'));
        self::$STORE = TextFormat::colorize($this->getConfig()->get('store'));
        self::$PREFIX = TextFormat::colorize($this->getConfig()->get('prefix'));

        self::$commonLoot = ItemSerializerUtils::deSerialize(base64_decode($this->getConfig()->get('common_loot')));
        self::$exclusiveLoot = ItemSerializerUtils::deSerialize(base64_decode($this->getConfig()->get('exclusive_loot')));

        $this->getServer()->getCommandMap()->register('Mystery Crate', new MysteryCrateCommand($this, 'mysterycrate', 'Use this command to manage the server mystery crate.'));
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        EntityFactory::getInstance()->register(ItemEntity::class, function(World $world, CompoundTag $nbt) : ItemEntity{
            $itemTag = $nbt->getCompoundTag("Item");

            if ($itemTag === null) {
                throw new SavedDataLoadingException("Expected \"Item\" NBT tag not found");
            }
            $item = Item::nbtDeserialize($itemTag);

            if ($item->isNull()) {
                throw new SavedDataLoadingException("Item is invalid");
            }

            $entity = new ItemEntity(Helper::parseLocation($nbt, $world), $item, $nbt);
            $entity->flagForDespawn();
            return $entity;
        }, ['Item', 'minecraft:item']);

        EntityFactory::getInstance()->register(FloatingText::class, function (World $world, CompoundTag $nbt): FloatingText {
            $entity = new FloatingText(Helper::parseLocation($nbt, $world), $nbt);
            $entity->flagForDespawn();
        return $entity;
    }, ["FloatingText"]);
    }

    protected function onDisable(): void
    {
        $this->getConfig()->set('common_loot', base64_encode(ItemSerializerUtils::serialize(self::$commonLoot)));
        $this->getConfig()->set('exclusive_loot', base64_encode(ItemSerializerUtils::serialize(self::$exclusiveLoot)));
        $this->saveConfig();
    }


    public static function setCommonLoot(array $commonLoot): void
    {
        self::$commonLoot = $commonLoot;
    }


    public static function setExclusiveLoot(array $exclusiveLoot): void
    {
        self::$exclusiveLoot = $exclusiveLoot;
    }

    public static function getCommonLoot(): array
    {
        return self::$commonLoot;
    }

    public static function getExclusiveLoot(): array
    {
        return self::$exclusiveLoot;
    }

    public static function getMysteryCrateItem(int $count = 1): Item
    {
        $item = VanillaBlocks::BEACON()->asItem();
        $item->setCount($count);
        $item->setCustomName(TextFormat::colorize(self::$NAME));
        $item->getNamedTag()->setInt('mystery_crate', 1);

        $lore = [
            '&bUnlock at ' . self::$STORE,
            ' ',
            '&a&lCOMMON'
        ];

        $colors = [
            TextFormat::DARK_GREEN,
            TextFormat::GREEN,
            TextFormat::YELLOW,
            TextFormat::GOLD,
            TextFormat::RED,
            TextFormat::DARK_RED,
            TextFormat::AQUA,
            TextFormat::DARK_AQUA,
            TextFormat::BLUE,
            TextFormat::DARK_BLUE,
            TextFormat::LIGHT_PURPLE,
            TextFormat::DARK_PURPLE,
        ];

        $iColor = 0;
        $countItem = 0;

        foreach (self::$commonLoot as $itemCommon) {
            $countItem++;
            $count = $itemCommon->getCount() > 1 ? $itemCommon->getCount() . ' ' : '';
            $lore[] = TextFormat::GRAY . '* ' . $colors[$iColor] . $count . TextFormat::clean($itemCommon->getCustomName() !== '' ? $itemCommon->getCustomName() : $itemCommon->getName());

            if ($countItem % 3 == 0) {
                $iColor = ($iColor + 1) % count($colors);
            }
        }

        $lore[] = ' ';
        $lore[] = '&c&lEXCLUSIVE';

        foreach (self::$exclusiveLoot as $itemExclusive) {
            $countItem++;
            $count = $itemExclusive->getCount() > 1 ? $itemExclusive->getCount() . ' ' : '';
            $lore[] = TextFormat::GRAY . '* ' . $colors[$iColor] . $count . TextFormat::clean($itemExclusive->getCustomName() !== '' ? $itemExclusive->getCustomName() : $itemExclusive->getName());

            if ($countItem % 3 == 0) {
                $iColor = ($iColor + 1) % count($colors);
            }
        }

        $l = [];

        foreach ($lore as $line) {
            $l[] = TextFormat::RESET . TextFormat::colorize($line);
        }

        $item->setLore($l);

        return $item;
    }


    public static function hasMysteryItem(Item $item): bool
    {
        return $item->getNamedTag()->getTag('mystery_crate') !== null;
    }
    
     /**
     * @param PlayerCreationEvent $event
     */
    public function handleCreation(PlayerCreationEvent $event): void
    {
        $event->setPlayerClass(Player::class);
    }

    // ...

    public function playerItemUseEvent(PlayerItemUseEvent $ev): void
    {
        $item = $ev->getItem();
        $player = $ev->getPlayer();
        
        if (!self::hasMysteryItem($item)) return;
        
        if ($this->openCooldown->hasCooldown($player)) {
            $player->sendMessage(TextFormat::RED . 'To open another mystery box again you must wait ' . $this->openCooldown->getRemaining($player) . '.');
            return;
        }
        if (count(self::$commonLoot) == 0 or count(self::$exclusiveLoot) == 0) {
            $player->sendMessage(TextFormat::RED . 'The mystery box content is empty.');
            return;
        }
        $item->pop();
        $this->playAnimation($player);
        $player->getInventory()->setItemInHand($item);
        $this->openCooldown->applyCooldown($player, 15);
        $ev->cancel();
    }



    public function placeBlockEvent(BlockPlaceEvent $ev): void
    {
        $item = $ev->getItem();
        if (self::hasMysteryItem($item)) $ev->cancel();
    }
    public function playAnimation(Player $player): void
    {
        $this->getServer()->broadcastMessage(TextFormat::colorize(self::$PREFIX) . TextFormat::RED . $player->getName() . TextFormat::WHITE . ' is opening ' . TextFormat::colorize(self::$NAME));
        $circleItems = [];
        $itemCount = 7;
        $center = $player->getLocation();
        for ($i = 0; $i < $itemCount; $i++) {
            $itemEntity = new ItemEntity($center, self::getRandomCommonReward());
            $itemEntity->spawnToAll();
            $circleItems[$i] = $itemEntity;
        }

        $this->getScheduler()->scheduleRepeatingTask(new AnimationTask($center, $circleItems, $player), 2);
    }

    public static function getRandomExlusiveReward(): Item
    {
        return self::$exclusiveLoot[array_rand(self::$exclusiveLoot)];
    }

    public static function getRandomCommonReward(): Item
    {
        return self::$commonLoot[array_rand(self::$commonLoot)];
    }

}