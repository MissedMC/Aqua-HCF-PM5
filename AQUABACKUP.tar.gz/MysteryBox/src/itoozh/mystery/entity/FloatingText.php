<?php

namespace itoozh\mystery\entity;


use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\utils\TextFormat;

class FloatingText extends Living{

    protected float $scale = 0.001;
    protected bool $gravityEnabled = false;

    public function __construct(Location $location, string $text)
    {
        $this->setNameTagAlwaysVisible();
        $this->setNameTag(TextFormat::colorize($text));
        parent::__construct($location);
    }

    public function attack(EntityDamageEvent $source): void
    {
        $source->cancel();
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0,0,0);
    }


    public static function getNetworkTypeId(): string
    {
        return EntityIds::CHICKEN;
    }

    public function getName(): string
    {
        return "FloatingText";
    }
}