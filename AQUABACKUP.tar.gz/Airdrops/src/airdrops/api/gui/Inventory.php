<?php

namespace airdrops\api\gui;

use airdrops\api\gui\utils\CallbackInventory;

use pocketmine\player\Player;
use pocketmine\inventory\SimpleInventory;
use pocketmine\block\inventory\BlockInventoryTrait;

abstract class Inventory extends SimpleInventory {
    use CallbackInventory, BlockInventoryTrait;

    /**
     * @param Player $who
     * @return void
     */
    public function onOpen(Player $who) : void {
        if(($callable = $this->getOpenCallable()) !== null){
            $callable($who, $this);
        }
        parent::onOpen($who);
    }

    /**
     * @param Player $who
     * @return void
     */
    public function onClose(Player $who) : void {
        if(($callable = $this->getCloseCallable()) !== null){
            $callable($who, $this);
        }
        parent::onClose($who);
    }
}

?>