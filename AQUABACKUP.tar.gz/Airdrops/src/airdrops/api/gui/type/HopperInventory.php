<?php

namespace airdrops\api\gui\type;

use airdrops\api\gui\utils\CallbackInventory;
use airdrops\api\gui\utils\WhateverInventory;

use pocketmine\world\Position;
use pocketmine\player\Player;
use pocketmine\block\inventory\BlockInventory;

class HopperInventory extends \pocketmine\block\inventory\HopperInventory implements BlockInventory, WhateverInventory {
    use CallbackInventory;

    /** @var bool */
    protected bool $interactable = false;

    /**
     * HopperInventory Constructor.
     * @param Player $player
     * @param Position $holder
     */
    public function __construct(Player $player, Position $holder){
        $this->player = $player;
        $this->holder = $holder;
        parent::__construct($holder);
    }

    /**
     * @return bool
     */
    public function isInteractable() : bool {
        return $this->interactable;
    }

    /**
     * @param bool $v
     * @return void
     */
    public function interactable(bool $v) : void {
        $this->interactable = $v;
    }

    /**
     * @param Player $who
     * @return void
     */
    public function onOpen(Player $who) : void {
        if(($callable = $this->getOpenCallable()) !== null){
            $callable($who, $this);
        }
        parent::onOpen($who);
    }

    /**
     * @param Player $who
     * @return void
     */
    public function onClose(Player $who) : void {
        if(($callable = $this->getCloseCallable()) !== null){
            $callable($who, $this);
        }
        parent::onClose($who);
    }
}

?>
