<?php

namespace airdrops\other;

use airdrops\HCFLoaderAirDrop;

use airdrops\api\form\IForm;
use airdrops\api\form\BasicForm;

use pocketmine\utils\Config;
use pocketmine\plugin\PluginException;

trait IData {

    /** @var Config */
    protected Config $config;

    /**
     * @param Config $config
     * @return void
     */
    public function setFileIterator(Config $config) : void {
        $this->config = $config;
    }

    /**
     * @return Config
     */
    public function getFileIterator() : Config {
        return $this->config;
    }

    /**
     * @param mixed $data
     * @return void
     */
    protected function removeFromFileIterator(mixed $data) : void {
        try {
            if(!($it = $this->getFileIterator())->exists($data)){
                throw new PluginException("Index '$data' does exist into ".realpath($this->getFileIterator()->getPath()));
            }
            $it->remove($data);
            $it->save();
        } catch(\Exception $exception){
            HCFLoaderAirDrop::getInstance()->getLogger()->warning($exception->getMessage());
        }
    }

    /**
     * @param mixed $data
     * @return void
     */
    abstract public function processSerializeData(mixed $data) : void;

    /**
     * @param callable|null $func
     * @return IForm
     */
    public static function menu(?callable $func) : IForm {
        return new BasicForm($func);
    }
}

?>