<?php

namespace airdrops;

use airdrops\other\airdrop\command\AirDropCommand;
use airdrops\other\airdrop\listener\AirDropListener;
use airdrops\other\DataLoader;
use airdrops\world\entities\ThreeDimensions\type\AirDrop3D;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\world\World;

class HCFLoaderAirDrop extends PluginBase {

    /** @var HCFLoaderAirDrop */
    protected static HCFLoaderAirDrop $instance;

    /** @var Config */
    public static Config $messages;

    /**
     * @return void
     */
    public function onLoad() : void {
        self::$instance = $this;
    }

    /**
     * @return void
     */
    public function onEnable() : void {

        if(!is_dir($this->getDataFolder()."other")){
            @mkdir($this->getDataFolder()."other");
        }

        foreach($this->getResources() as $resource => $fileInfo){
            $this->saveResource($resource, $this->isDevelopmentVersion());
        }
        $this->saveDefaultConfig();

        EntityFactory::getInstance()->register(AirDrop3D::class, function(World $world, CompoundTag $nbt) : AirDrop3D {
            return new AirDrop3D(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['AirDrop3D']);

        self::$messages = new Config($this->getDataFolder()."messages.yml", Config::YAML);

        DataLoader::getInstance()->load();

        $this->getServer()->getPluginManager()->registerEvents(new AirDropListener(), $this);
        $this->getServer()->getCommandMap()->register("airdrop", new AirDropCommand("airdrop", "AirDrop Management", DefaultPermissionNames::GROUP_OPERATOR, []));
    }

    /**
     * @return void
     */
    public function onDisable() : void {
        DataLoader::getInstance()->save();
    }

    /**
     * @return static
     */
    public static function getInstance() : self {
        return self::$instance;
    }

    /**
     * @return bool
     */
    protected function isDevelopmentVersion() : bool {
        return true;
    }
}

?>