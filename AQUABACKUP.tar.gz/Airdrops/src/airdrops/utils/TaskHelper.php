<?php

namespace airdrops\utils;

use airdrops\HCFLoaderAirDrop;

use pocketmine\scheduler\Task;
use pocketmine\scheduler\TaskHandler;

use pocketmine\scheduler\AsyncTask;

use pocketmine\plugin\PluginException;

final class TaskHelper {

    /** @var array<int, callable> */
    protected static array $callbacks = [];

    /** @var int */
    const REPEATING = 0;
    /** @var int */
    const DELAYED = 1;

    /**
     * @param Task $task
     * @param int $type
     * @param int $whatever
     * @return TaskHandler
     */
    public static function runAnyTask(Task $task, int $type, int $whatever = 1) : TaskHandler {
        return match($type){
            self::REPEATING => HCFLoaderAirDrop::getInstance()->getScheduler()->scheduleRepeatingTask($task, $whatever),
            self::DELAYED => HCFLoaderAirDrop::getInstance()->getScheduler()->scheduleDelayedTask($task, $whatever),
            default => throw new PluginException("Task $type does not exist in the allowed tasks"),
        };
    }

    /**
     * @param AsyncTask $task
     * @return int
     */
    public static function runAsyncTask(AsyncTask $task) : int {
        return HCFLoaderAirDrop::getInstance()->getServer()->getAsyncPool()->submitTask($task);
    }
}

?>