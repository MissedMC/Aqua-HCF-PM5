<?php

namespace airdrops\utils\item;

use pocketmine\item\ItemTypeIds;
use pocketmine\utils\TextFormat;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;

use airdrops\item\enchantment\Enchantment as CustomEnchantment;

use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;

use pocketmine\data\bedrock\EnchantmentIdMap;

final class EnchantmentDeserializer {

    /**
     * @param Item $item
     * @return Item
     */
    public static function deserialize(Item $item) : Item {
        $tag = $item->getNamedTag();

        $enchantments = $tag->getListTag(Item::TAG_ENCH);
        if($enchantments !== null && $enchantments->getTagType() === NBT::TAG_Compound){
            /** @var CompoundTag $enchantment */
            foreach($enchantments as $enchantment){
                $magicNumber = $enchantment->getShort("id", -1);
                $level = $enchantment->getShort("lvl", 0);
                if($level <= 0){
                    continue;
                }
                $type = EnchantmentIdMap::getInstance()->fromId($magicNumber);
                if($type instanceof CustomEnchantment){
                    $type->setEffectLevel($level);

                    $item->addEnchantment(new EnchantmentInstance($type, $level));
                }
            }
        }
        return $item;
    }

    /**
     * @param Item $item
     * @param Enchantment $ench
     * @param int $level
     * @return Item
     */
    public static function ench(Item $item, Enchantment $ench, int $level) : Item {
        if($ench instanceof CustomEnchantment){
            if(count(($newLore = $item->getLore())) !== 0){
                foreach($newLore as $id => $actuallyLore){
                    if(substr(TextFormat::clean($actuallyLore), 0, strlen($ench->getDisplayName())) === $ench->getDisplayName()){
                        unset($newLore[$id]);
                    }
                }
            }
            if($ench->getLore($level) !== null){
                $newLore[] = $ench->getLore($level);
                $item->setLore($newLore);
            }
            $ench->setEffectLevel($level);
        }
        return $item->addEnchantment(new EnchantmentInstance($ench, $level));
    }

    /**
     * @param Item $item
     * @return bool
     */
    public static function compatible(Item $item) : bool {
        $class = new \ReflectionClass(ItemTypeIds::class);

        $constants = array_filter($class->getConstants(), fn(string $constant) => str_contains($constant, "HELMET") || str_contains($constant, "CHESTPLATE") || str_contains($constant, "LEGGINGS") || str_contains($constant, "BOOTS"), ARRAY_FILTER_USE_KEY);
        foreach($constants as $name => $id){
            if(str_contains($name, "GOLD") || str_contains($name, "GOLDEN") || str_contains($name, "IRON") || str_contains($name, "LEATHER") || str_contains($name, "CHAIN")){
                continue;
            }
            if(str_contains(str_replace("_", " ", strtolower($name)), strtolower($item->getVanillaName()))){
                return true;
            }
        }
        return false;
    }
}

?>