<?php

namespace airdrops\utils;

use pocketmine\item\Durable;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\LegacyStringToItemParser;
use pocketmine\item\LegacyStringToItemParserException;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\utils\TextFormat;
use pocketmine\world\format\io\GlobalItemDataHandlers;

final class Translator {

    public static function encodeItem(Item $item): string
    {
        $serializer = new LittleEndianNbtSerializer();
        return base64_encode($serializer->write(new TreeRoot($item->nbtSerialize())));
    }

    public static function decodeItem(string|array $data): ?Item
    {
        if(is_array($data)){
            return self::jsonDeserialize($data);
        }
        $serializer = new LittleEndianNbtSerializer();
        try {
            $item = Item::nbtDeserialize($serializer->read(base64_decode($data))->mustGetCompoundTag());
        } catch (SavedDataLoadingException|\Exception $e) {
            throw new \RuntimeException("Error during decoding of an item, incorrect item: " . $e->getMessage(). ", data: ".$data);
            return null;
        }
        return $item;
    }

    final public static function jsonDeserialize(array $data) : Item{
        $nbt = "";

        //Backwards compatibility
        if(isset($data["nbt"])){
            $nbt = $data["nbt"];
        }elseif(isset($data["nbt_hex"])){
            $nbt = hex2bin($data["nbt_hex"]);
        }elseif(isset($data["nbt_b64"])){
            $nbt = base64_decode($data["nbt_b64"], true);
        }
        $item = GlobalItemDataHandlers::getDeserializer()->deserializeStack(GlobalItemDataHandlers::getUpgrader()->upgradeItemTypeDataInt((int) $data["id"], (int) ($data["damage"] ?? 0), (int) ($data["count"] ?? 1), $nbt !== "" ? (new LittleEndianNbtSerializer())->read($nbt)->mustGetCompoundTag() : null));
        return $item;

    }

    /**
     * @param string $item
     * @return Item
     */
    public static function stringToItem(string $item) : Item {
        $data = unserialize($item);
        $nbt = "";
        if(isset($data["nbt"])){
            $nbt = $data["nbt"];
        }elseif(isset($data["nbt_hex"])){
            $nbt = hex2bin($data["nbt_hex"]);
        }elseif(isset($data["nbt_b64"])){
            $nbt = base64_decode($data["nbt_b64"], true);
        }
        $itemMapping = LegacyStringToItemParser::getInstance()->getMappings();
        $legacyLower = strtolower((string) $data['id']);
        $legacy = $itemMapping[$legacyLower] ?? null;

        if ($legacy === null) {
            throw new LegacyStringToItemParserException("Unable to resolve \"" . $data['id'] . "\" to a valid item");
        }
        $itemStack = GlobalItemDataHandlers::getUpgrader()->upgradeItemTypeDataString($legacy, intval($itemData['meta'] ?? 0), intval($itemData['count'] ?? 1), null);
        $item = GlobalItemDataHandlers::getDeserializer()->deserializeStack($itemStack);

        if (isset($itemData['custom-name'])) {
            $item->setCustomName(TextFormat::colorize('&r' . $itemData['custom-name']));
        }

        if (isset($itemData['unbreakable']) && $item instanceof Durable) {
            $item->setUnbreakable((bool) $itemData['unbreakable']);
        }
        $enchantments = $itemData['enchantments'] ?? [];
        array_map(fn(int $enchantId, int $enchantLevel) => $item->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId($enchantId), $enchantLevel)), array_keys($enchantments), array_values($enchantments));
        return $item;
    }

    /**
     * @param Item $item
     * @return string
     */
    public static function itemToString(Item $item) : string {
        $data = [
            "id" => $item->getTypeId()
        ];
        if($item->getTypeId() !== 0){
            $data["damage"] = $item->getStateId();
        }
        if($item->getCount() !== 1){
            $data["count"] = $item->getCount();
        }
        if($item->hasNamedTag()){
            $data["nbt_b64"] = base64_encode((new LittleEndianNbtSerializer())->write(new TreeRoot($item->getNamedTag())));
        }
        return serialize($data);
    }
}

?>