<?php /** @noinspection PhpUndefinedClassInspection */

namespace airdrops\utils\skin;

use airdrops\HCFLoaderAirDrop;
use Ramsey\Uuid\Uuid;
use pocketmine\entity\Skin;

final class Skin3D {

    /**
     * @param string $pngPath
     * @param string $jsonPath
     * @param string $geometryName
     * @return Skin|null
     */
    public static function process(string $pngPath, string $jsonPath, string $geometryName) : ?Skin {
        $size = @getimagesize($pngPath);
        $img = @imagecreatefrompng($pngPath);

        $bytes = "";
        for($y = 0; $y < $size[1]; $y++){
            for($x = 0; $x < $size[0]; $x++){
                $color = @imagecolorat($img, $x, $y);
                $a = ((~($color >> 24)) << 1) & 0xff;
                $r = ($color >> 16) & 0xff;
                $g = ($color >> 8) & 0xff;
                $b = $color & 0xff;
                $bytes .= chr($r).chr($g).chr($b).chr($a);;
            }
        }
        @imagedestroy($img);

        $jsonContents = file_get_contents($jsonPath);

        try {
            return new Skin(Uuid::uuid4()->toString(), $bytes, "", $geometryName, $jsonContents);
        } catch(\JsonException $exception){
            HCFLoaderAirDrop::getInstance()->getLogger()->warning($exception->getMessage());
            return null;
        }
    }
}

?>