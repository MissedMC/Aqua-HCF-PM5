<?php

declare(strict_types = 1);

namespace IvanCraft623\RankSystem\libs\jojoe77777\FormAPI;

use pocketmine\plugin\PluginBase;

class FormAPI extends PluginBase{

}
