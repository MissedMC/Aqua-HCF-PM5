<?php

namespace qXoap;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\player\Player;

class EventListener implements Listener {

    public function onPlayerJoin(PlayerJoinEvent $event)
    {
        if(!Tops::getInstance()->getProvider()->isPlayerRegistered($event->getPlayer())){
            Tops::getInstance()->getProvider()->register($event->getPlayer());
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $ev)
    {
        $player = $ev->getPlayer();
        $cause = $ev->getEntity()->getLastDamageCause();
        Tops::getInstance()->getProvider()->addDeath($player);
        if (!$cause instanceof EntityDamageByEntityEvent) return;
        $damager = $cause->getDamager();
        if (!$damager instanceof Player) return;
        Tops::getInstance()->getProvider()->addKill($damager);
    }
}