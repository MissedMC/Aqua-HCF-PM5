<?php

namespace qXoap;

use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use qXoap\command\SetEntityCommand;
use qXoap\entity\DeathEntity;
use qXoap\entity\FactionsEntity;
use qXoap\entity\KillsEntity;
use qXoap\provider\YamlProvider;
use pocketmine\nbt\tag\CompoundTag;

class Tops extends PluginBase{
    use SingletonTrait;

    public const PREFIX = "§8(§bTops§8) §7";

    public $provider;

    public function onLoad(): void
    {
        self::setInstance($this);
    }

    public function onEnable(): void
    {
        $this->provider = new YamlProvider();
        Server::getInstance()->getCommandMap()->register("tops", new SetEntityCommand());
        Server::getInstance()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->saveResource("kills.yml");
        $this->saveResource("deaths.yml");
        $this->saveResource("config.yml");

        // REGISTER ENTITYS

        EntityFactory::getInstance()->register(KillsEntity::class, function (World $world, CompoundTag $nbt) : KillsEntity {
            return new KillsEntity(EntityDataHelper::parseLocation($nbt, $world), KillsEntity::parseSkinNBT($nbt), $nbt);
        }, ['KillEntity']);

        EntityFactory::getInstance()->register(DeathEntity::class, function (World $world, CompoundTag $nbt) : DeathEntity {
            return new DeathEntity(EntityDataHelper::parseLocation($nbt, $world), DeathEntity::parseSkinNBT($nbt), $nbt);
        }, ['DeathEntity']);

        EntityFactory::getInstance()->register(FactionsEntity::class, function (World $world, CompoundTag $nbt) : FactionsEntity {
            return new FactionsEntity(EntityDataHelper::parseLocation($nbt, $world), FactionsEntity::parseSkinNBT($nbt), $nbt);
        }, ['FactionsEntity']);

    }

    public function getProvider(): YamlProvider
    {
        return $this->provider;
    }
}