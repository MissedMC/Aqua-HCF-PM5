<?php

namespace qXoap\provider;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use qXoap\Tops;

class YamlProvider {

    public function isPlayerRegistered(Player $player)
    {
        $kills = new Config(Tops::getInstance()->getDataFolder() . "kills.yml", Config::YAML);
        $deaths = new Config(Tops::getInstance()->getDataFolder() . "deaths.yml", Config::YAML);
        if($kills->exists($player->getName())){
            return true;
        }
        if($deaths->exists($player->getName())){
            return true;
        }
        return false;
    }

    public function register(Player $player)
    {
        $kills = new Config(Tops::getInstance()->getDataFolder() . "kills.yml", Config::YAML);
        $kills->set($player->getName(), 0);
        $kills->save();
        $deaths = new Config(Tops::getInstance()->getDataFolder() . "deaths.yml", Config::YAML);
        $deaths->set($player->getName(), 0);
        $deaths->save();
    }

    public function getAllKills()
    {
        $config = new Config(Tops::getInstance()->getDataFolder() . "kills.yml", Config::YAML);
        return $config->getAll();
    }

    public function addKill(Player $player): void
    {
        $config = new Config(Tops::getInstance()->getDataFolder() . "kills.yml", Config::YAML);
        $config->set($player->getName(), $config->get($player->getName()) + 1);
        $config->save();
    }

    public function getAllDeaths()
    {
        $config = new Config(Tops::getInstance()->getDataFolder() . "deaths.yml", Config::YAML);
        return $config->getAll();
    }

    public function addDeath(Player $player): void
    {
        $config = new Config(Tops::getInstance()->getDataFolder() . "deaths.yml", Config::YAML);
        $config->set($player->getName(), $config->get($player->getName()) + 1);
        $config->save();
    }
}