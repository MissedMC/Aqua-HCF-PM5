<?php

namespace qXoap\entity;

use hcf\HCFLoader;
use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use qXoap\Tops;

class FactionsEntity extends Human {

    public static function create(Player $player) : self {

        $nbt = CompoundTag::create()->setTag("Pos", new ListTag([

            new DoubleTag($player->getLocation()->x),

            new DoubleTag($player->getLocation()->y),

            new DoubleTag($player->getLocation()->z)

        ]))->setTag("Motion", new ListTag([

            new DoubleTag($player->getMotion()->x),

            new DoubleTag($player->getMotion()->y),

            new DoubleTag($player->getMotion()->z)

        ]))->setTag("Rotation", new ListTag([

            new FloatTag($player->getLocation()->yaw),

            new FloatTag($player->getLocation()->pitch)

        ]));

        return new self($player->getLocation(), $player->getSkin(), $nbt);

    }

    public function onUpdate(int $currentTick): bool {
    $parent = parent::onUpdate($currentTick);
    $data = $this->getFactions();
    arsort($data);
    $top = 1;
    $tag = TextFormat::colorize('&l&6TOP FACTIONS');
    
    for ($i = 0; $i < 10; $i++) {
        $position = $i + 1;
        $factions = array_keys($data);
        $points = array_values($data);
        
        if (isset($factions[$i])) {
            $message = Tops::getInstance()->getConfig()->get("top-factions-format");
            $message = str_replace("{FACTION}", $factions[$i], $message);
            $message = str_replace("{POWER}", $points[$i], $message);
            $message = str_replace("{TOP}", $position, $message);
            
            $tag .= PHP_EOL . TextFormat::colorize($message);
            $top++;
        }
    }
    
    $this->setNameTag($tag);
    $this->setNameTagAlwaysVisible(true);
    $this->setNoClientPredictions(true);
    $this->setScale(1.0);
    
    return $parent;
    }

    public function attack(EntityDamageEvent $source) : void {

        $source->cancel();

        if (!$source instanceof EntityDamageByEntityEvent) {

            return;

        }

        $damager = $source->getDamager();

        if (!$damager instanceof Player) {

            return;

        }

        if ($damager->getInventory()->getItemInHand()->getTypeId() === 450) {

            if ($damager->hasPermission(DefaultPermissions::ROOT_OPERATOR)) {

                $this->kill();

            }

            return;
        }
    }
    private function getFactions(): array
    {
        $points = [];
        
        foreach (HCFLoader::getInstance()->getFactionManager()->getFactions() as $name => $faction) {
            if (in_array($faction->getName(), ['Spawn', 'North Road', 'South Road', 'East Road', 'West Road', 'Nether Spawn', 'End Spawn']))
                continue;
            $points[$name] = $faction->getPoints();
        }
        return $points;
    }
}