<?php

namespace qXoap\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use qXoap\entity\DeathEntity;
use qXoap\entity\FactionsEntity;
use qXoap\entity\KillsEntity;
use qXoap\Tops;

class SetEntityCommand extends Command {

    public function __construct()
    {
        parent::__construct("tops", "Set Top Entity", null, []);
        $this->setPermission("tops.cmd");
    }

    public function execute(CommandSender $player, string $commandLabel, array $args)
    {
        if(!$player instanceof Player)return;

        if(!$player->hasPermission("tops.cmd")){
            $player->sendMessage(Tops::PREFIX."No Tienes Permisos Suficientes Para Usar Esto!");
            return;
        }

        if(!isset($args[0])){
            $player->sendMessage(Tops::PREFIX."Usa /tops (kills:deaths:factions)");
            return;
        }

        switch (strtolower($args[0])){
            case "kills":
                KillsEntity::create($player)->spawnToAll();
                $player->sendMessage(Tops::PREFIX."La Entidad Top Kills Se Creo Con Exito");
                $player->sendMessage(Tops::PREFIX."Para Eliminarla Pegale con un Totem, pero asegurate de tener permisos de opeador!");
                break;
            case "deaths":
                DeathEntity::create($player)->spawnToAll();
                $player->sendMessage(Tops::PREFIX."La Entidad Top Kills Se Creo Con Exito");
                $player->sendMessage(Tops::PREFIX."Para Eliminarla Pegale con un Totem, pero asegurate de tener permisos de opeador!");
                break;
            case "factions":
                FactionsEntity::create($player)->spawnToAll();
                $player->sendMessage(Tops::PREFIX."La Entidad Top Factions Se Creo Con Exito");
                $player->sendMessage(Tops::PREFIX."Para Eliminarla Pegale con un Totem, pero asegurate de tener permisos de opeador!");
                break;
            case "help":
                $player->sendMessage(" ");
                $player->sendMessage(" §7Plugin Crated By qXoap(§cSxxCodezx§7) ");
                $player->sendMessage(" ");
                break;

            default:
                $player->sendMessage(Tops::PREFIX."Usa /tops (kills:deaths:factions)");
        }
    }
}