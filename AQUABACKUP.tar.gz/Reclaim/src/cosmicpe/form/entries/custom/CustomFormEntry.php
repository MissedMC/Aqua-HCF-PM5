<?php

declare(strict_types=1);

namespace cosmicpe\form\entries\custom;

use cosmicpe\form\entries\FormEntry;

interface CustomFormEntry extends FormEntry { }