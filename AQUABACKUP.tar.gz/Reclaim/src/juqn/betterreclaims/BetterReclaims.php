<?php

declare(strict_types=1);

namespace juqn\betterreclaims;

use juqn\betterreclaims\command\ReclaimCommand;
use juqn\betterreclaims\reclaim\ReclaimFactory;
use juqn\betterreclaims\session\SessionFactory;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\event\EventPriority;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use ReflectionException;

final class BetterReclaims extends PluginBase {
    use SingletonTrait;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    /**
     * @throws ReflectionException
     */
    protected function onEnable(): void {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        $this->saveDefaultConfig();

        $this->getServer()->getCommandMap()->register('Reclaims', new ReclaimCommand());
        $this->getServer()->getPluginManager()->registerEvent(PlayerLoginEvent::class, function (PlayerLoginEvent $event): void {
            $player = $event->getPlayer();
            $session = SessionFactory::get($player);

            if ($session === null) {
                SessionFactory::create($player);
            }
        }, EventPriority::NORMAL, $this);

        ReclaimFactory::load();
        SessionFactory::load();
    }

    protected function onDisable(): void {
        ReclaimFactory::save();
        SessionFactory::save();
    }
}