<?php

declare(strict_types=1);

namespace juqn\betterreclaims\command;

use juqn\betterreclaims\BetterReclaims;
use juqn\betterreclaims\reclaim\Reclaim;
use juqn\betterreclaims\reclaim\ReclaimFactory;
use juqn\betterreclaims\session\SessionFactory;
use juqn\betterreclaims\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

final class ReclaimCommand extends Command {

    public function __construct() {
        parent::__construct('reclaim', 'Use command to reclaims.');
        $this->setPermission('reclaim.command.use');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::colorize('&cUse command in game.'));
            return;
        }
        $session = SessionFactory::get($sender);

        if ($session === null) {
            return;
        }

        if (!$sender->hasPermission('reclaim.command') || !isset($args[0])) {
            
            foreach (ReclaimFactory::getAll() as $reclaimName => $reclaim) {
                if ($sender->hasPermission($reclaim->getPermission())) {
                    $cooldown = $session->getCooldown($reclaimName);
                    
                    if ($cooldown !== null && $cooldown->isExpired()) {
                        $sender->sendMessage(TextFormat::colorize('&7'.$reclaimName.'&c You have cooldown to use it again you must wait ' . Utils::convert($cooldown->getTime() - time())));
                        return;
                    }
                    foreach ($reclaim->getContent() as $item) {
                        if ($sender->getInventory()->canAddItem($item)) {
                            $sender->getInventory()->addItem($item);
                        } else {
                            $sender->dropItem($item);
                        }
                    }
                    $sender->getServer()->broadcastMessage(TextFormat::colorize(str_replace(['{player}', '{reclaim_name}'], [$sender->getName(), $reclaimName], BetterReclaims::getInstance()->getConfig()->getNested('broadcast-message'))));
                    $session->addCooldown($reclaimName, $reclaim->getCooldown());
                }
            }
            
            /*$reclaims = array_filter(ReclaimFactory::getAll(), fn(Reclaim $reclaim) => $reclaim->getPermission() === null || $sender->hasPermission($reclaim->getPermission()));
            
            foreach ($reclaims as $reclaimName => $reclaim) {
                $cooldown = $session->getCooldown($reclaimName);

                if ($cooldown !== null && $cooldown->isExpired()) {
                    $sender->sendMessage(TextFormat::colorize('&7'.$reclaimName.'&c You have cooldown to use it again you must wait ' . Utils::convert($cooldown->getTime() - time())));
                    continue;
                }

                foreach ($reclaim->getContent() as $item) {
                    if ($sender->getInventory()->canAddItem($item)) {
                        $sender->getInventory()->addItem($item);
                    } else {
                        $sender->dropItem($item);
                    }
                }
                $sender->getServer()->broadcastMessage(TextFormat::colorize(str_replace(['{player}', '{reclaim_name}'], [$sender->getName(), $reclaimName], BetterReclaims::getInstance()->getConfig()->getNested('broadcast-message'))));
                $session->addCooldown($reclaimName, $reclaim->getCooldown());
            }*/
            return;
        }

        switch (strtolower($args[0])) {
            case 'help':
                $lines = [
                    '&5Reclaim Commands&r',
                    '&5/reclaim create &7- &fUse command to create new reclaim',
                    '&5/reclaim delete &7- &fUse command to remove the reclaim'
                ];
                $sender->sendMessage(TextFormat::colorize(implode(PHP_EOL, $lines)));
                break;

            case 'create':
                if (count($args) < 3) {
                    $sender->sendMessage(TextFormat::colorize('&cUse /reclaim create [name] [time] [permission]'));
                    return;
                }
                $name = $args[1];
                $time = $args[2];
                $permission = $args[3];

                if (ReclaimFactory::get($name) !== null) {
                    $sender->sendMessage(TextFormat::colorize('&cReclaim already exists.'));
                    return;
                }

                try {
                    $reclaimTime = Utils::time($time);
                } catch (\InvalidArgumentException) {
                    $sender->sendMessage(TextFormat::colorize('&cInvalid time format.'));
                    return;
                }
                
                if (!isset($args[3])) {
                    $sender->sendMessage(TextFormat::colorize('&c Argument 3 is missing, you must enter the permission, example: user.reclaim.'));
                    return;
                }
                ReclaimFactory::create($name, $reclaimTime - time(), [], $permission);
                $sender->sendMessage(TextFormat::colorize('&aYou has been create reclaim: ' . $name . '. Now edit the content.'));

                Utils::createReclaimContent($name, $sender);
                break;

            case 'remove':
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::colorize('&cUse /reclaim remove [name]'));
                    return;
                }
                $name = $args[1];

                if (ReclaimFactory::get($name) === null) {
                    $sender->sendMessage(TextFormat::colorize('&cReclaim not exists.'));
                    return;
                }
                ReclaimFactory::remove($name);
                $sender->sendMessage(TextFormat::colorize('&aYou has been removed reclaim.'));
                break;
        }
    }
}