<?php

declare(strict_types=1);

namespace juqn\betterreclaims\session\cooldown;

final class Cooldown {

    public function __construct(
        private int $time
    ) {}

    public function getTime(): int {
        return $this->time;
    }

    public function isExpired(): bool {
        return $this->time >= time();
    }
}