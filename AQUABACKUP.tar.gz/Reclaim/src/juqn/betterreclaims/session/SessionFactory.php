<?php

declare(strict_types=1);

namespace juqn\betterreclaims\session;

use juqn\betterreclaims\BetterReclaims;
use pocketmine\player\Player;
use pocketmine\utils\Config;

final class SessionFactory {

    /** @var Session[] */
    private static array $sessions = [];

    public static function get(Player $player): ?Session {
        return self::$sessions[$player->getXuid()] ?? null;
    }

    public static function create(Player $player): void {
        self::$sessions[$player->getXuid()] = new Session();
    }

    public static function load(): void {
        if (!is_dir(BetterReclaims::getInstance()->getDataFolder() . 'database')) {
            @mkdir(BetterReclaims::getInstance()->getDataFolder() . 'database');
        }
        $config = new Config(BetterReclaims::getInstance()->getDataFolder() . 'database' . DIRECTORY_SEPARATOR . 'players.json', Config::JSON);

        foreach ($config->getAll() as $xuid => $data) {
            self::$sessions[$xuid] = Session::deserializeData($data);
        }
    }

    public static function save(): void {
        if (!is_dir(BetterReclaims::getInstance()->getDataFolder() . 'database')) {
            @mkdir(BetterReclaims::getInstance()->getDataFolder() . 'database');
        }
        $config = new Config(BetterReclaims::getInstance()->getDataFolder() . 'database' . DIRECTORY_SEPARATOR . 'players.json', Config::JSON);
        $data = [];

        foreach (self::$sessions as $xuid => $session) {
            $data[$xuid] = $session->serializeData();
        }
        $config->setAll($data);
        $config->save();
    }
}