<?php

declare(strict_types=1);

namespace juqn\betterreclaims\session;

use juqn\betterreclaims\session\cooldown\Cooldown;

final class Session {

    /**
     * @param Cooldown[] $cooldowns
     */
    public function __construct(
        private array $cooldowns = []
    ) {}

    public function getCooldown(string $reclaimName): ?Cooldown {
        return $this->cooldowns[$reclaimName] ?? null;
    }

    public function addCooldown(string $reclaimName, int $time): void {
        $this->cooldowns[$reclaimName] = new Cooldown($time + time());
    }

    public function serializeData(): array {
        return array_map(fn(Cooldown $cooldown) => $cooldown->getTime(), $this->cooldowns);
    }

    public static function deserializeData(array $data): self {
        return new self(array_map(fn(int $time) => new Cooldown($time), $data));
    }
}