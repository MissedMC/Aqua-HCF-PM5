<?php

declare(strict_types=1);

namespace juqn\betterreclaims;

use juqn\betterreclaims\reclaim\ReclaimFactory;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

final class Utils {

    public static function time(string $duration): int {
        $time_units = ['y' => 'year', 'M' => 'month', 'w' => 'week', 'd' => 'day', 'h' => 'hour', 'm' => 'minute'];
        $regex = '/^([0-9]+y)?([0-9]+M)?([0-9]+w)?([0-9]+d)?([0-9]+h)?([0-9]+m)?$/';
        $matches = [];
        $is_matching = preg_match($regex, $duration, $matches);

        if (!$is_matching) {
            throw new \InvalidArgumentException('Invalid duration. Please put numbers and letters');
        }
        $time = '';

        foreach ($matches as $index => $match) {
            if ($index === 0 || strlen($match) === 0) continue;
            $n = substr($match, 0, -1);
            $unit = $time_units[substr($match, -1)];
            $time .= "$n $unit ";
        }
        $time = trim($time);

        return $time === '' ? time() : strtotime($time);
    }
    
    public static function convert(int $time): string {
        if ($time < 60)
            return $time . 's';
        elseif ($time < 3600) {
            $minutes = intval($time / 60) % 60;
            return $minutes . 'm';
        } elseif ($time < 86400) {
            $hours = (int)($time / 3600) % 24;
            return (int)$hours . 'h';
        } else {
            $days = floor($time / 86400);
            return $days . 'd';
        }
    }

    public static function createReclaimContent(string $name, Player $player): void {
        $reclaim = ReclaimFactory::get($name);

        if ($reclaim === null) {
            return;
        }
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setInventoryCloseListener(function (Player $player, Inventory $inventory) use ($reclaim): void {
            $contents = array_values($inventory->getContents());
            $reclaim->setContent($contents);

            $player->sendMessage(TextFormat::colorize('&aYou reclaim has been updated.'));
        });

        $menu->send($player, TextFormat::colorize('&5Reclaim ' . $name));
    }
}