<?php

declare(strict_types=1);

namespace juqn\betterreclaims\reclaim;

use hcf\util\Serialize;
use itoozh\crates\Util;
use juqn\betterreclaims\BetterReclaims;
use pocketmine\utils\Config;

final class ReclaimFactory {

    /** @var Reclaim[] */
    private static array $reclaims = [];

    public static function getAll(): array {
        return self::$reclaims;
    }

    public static function get(string $name): ?Reclaim {
        return self::$reclaims[$name] ?? null;
    }

    public static function create(string $name, int $cooldown, array $content, ?string $permission): void {
        self::$reclaims[$name] = new Reclaim($cooldown, $content, $permission);
    }

    public static function remove(string $name): void {
        if (self::get($name) === null) {
            return;
        }
        unset(self::$reclaims[$name]);
    }

    public static function load(): void {
        if (!is_dir(BetterReclaims::getInstance()->getDataFolder() . 'database')) {
            @mkdir(BetterReclaims::getInstance()->getDataFolder() . 'database');
        }
        $config = new Config(BetterReclaims::getInstance()->getDataFolder() . 'database' . DIRECTORY_SEPARATOR . 'reclaims.json', Config::JSON);

        foreach ($config->getAll() as $reclaimName => $reclaimData) {
            self::$reclaims[$reclaimName] = Reclaim::deserializeData($reclaimData);
        }
    }

    public static function save(): void {
        if (!is_dir(BetterReclaims::getInstance()->getDataFolder() . 'database')) {
            @mkdir(BetterReclaims::getInstance()->getDataFolder() . 'database');
        }
        $config = new Config(BetterReclaims::getInstance()->getDataFolder() . 'database' . DIRECTORY_SEPARATOR . 'reclaims.json', Config::JSON);
        $data = [];

        foreach (self::$reclaims as $name => $reclaim) {
            $data[$name] = $reclaim->serializeData();
        }
        $config->setAll($data);
        $config->save();
    }
}