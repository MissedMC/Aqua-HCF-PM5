<?php

declare(strict_types=1);

namespace support\utils;

use support\Support;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

/**
 * Class Utils
 * @package support\utils
 */
final class Utils
{
    
    /**
     * @param string $partnerName
     * @return Item
     */
    public static function makeItem(string $partnerName): Item
    {
        $partner = Support::getInstance()->getPartner($partnerName);
        
        $item = VanillaBlocks::MOB_HEAD()->asItem();

        $item->setCustomName(TextFormat::colorize($partner['format']));
        
        if (is_array(Support::getInstance()->getConfig()->get('item.lore', [])))
            $item->setLore(['',
            '§r§6Click to support this creator.',
            '§r§eReward: §7x5 Partner Packages',
            "",
            "§r§bSupported: §r§e".$partner['amount_support'] ,
            '§r§7'                          ]);
        $namedtag = $item->getNamedTag();
        $namedtag->setString('support_name', $partnerName);
        $item->setNamedTag($namedtag);
        
        return $item;
    }
    
    /**
     * @param Player $player
     */
    public static function openSupportChest(Player $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TextFormat::colorize(Support::getInstance()->getConfig()->get( 'chest.name', 'Chest Support')));
        
        foreach (Support::getInstance()->getPartners()['organization'] as $slot => $name)
            $menu->getInventory()->setItem($slot, self::makeItem($name));
        $menu->setListener(function(InvMenuTransaction $transaction): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $item = $transaction->getItemClicked();
    
            if ($item->getNamedTag()->getTag('support_name')) {
                $player_data = Support::getInstance()->getPlayer($player->getName());
                $partner = Support::getInstance()->getPartner($item->getNamedTag()->getString('support_name'));
        
                if ($partner != null) {
                    if ($player_data === null or $player_data['time'] < time()) {
                        Support::getInstance()->setPlayer($player->getName(), (int) Support::getInstance()->getConfig()->get('cooldown.item', 120), $item->getNamedTag()->getString('support_name'));
                        Support::getInstance()->addSupport($item->getNamedTag()->getString('support_name'));

                        Server::getInstance()->dispatchCommand(new ConsoleCommandSender($server = Server::getInstance(), $server->getLanguage()), str_replace("{player}", '"' . $player->getName() . '"', Support::getInstance()->getConfig()->get('partner.command')));
                        
                        $player->sendMessage(TextFormat::colorize('&aAcabas de Apoyar a tu partner Favorito'));
                        $player->removeCurrentWindow();
                    } else $player->sendMessage(TextFormat::colorize('&cYou cannot support your partner because you have already supported him or have supported another partner'));
                } else {
                    $player->sendMessage(TextFormat::colorize('&cThis partner does not exist, please put the command again'));
                    $player->removeCurrentWindow();
                }
            } else $player->removeCurrentWindow();
            return $transaction->discard();
        });
        $menu->send($player);
    }
    
    /**
     * @param Player $player
     */
    public static function openSupportEditChest(Player $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName(TextFormat::colorize(Support::getInstance()->getConfig()->get( 'chest.edit.name', 'Chest Edit Support')));
        
        foreach (Support::getInstance()->getPartners()['organization'] as $slot => $name)
            $menu->getInventory()->setItem($slot, self::makeItem($name));
        $menu->setListener(function(InvMenuTransaction $transaction): InvMenuTransactionResult {
            $item = $transaction->getItemClickedWith();
            
            if (!$item->isNull() && !$item->getNamedTag()->getTag('support_name'))
                return $transaction->discard();
            return $transaction->continue();
        });
        $menu->setInventoryCloseListener(function (Player $player, $inventory): void {
            $contents = $inventory->getContents();
            Support::getInstance()->resetSlotsOrganization();
            
            foreach ($contents as $slot => $item)
                Support::getInstance()->setSlotOrganization($slot, $item->getNamedTag()->getString('support_name'));
            $player->sendMessage(TextFormat::colorize('&aYou have successfully edited the content of the Support Partners'));
        });
        $menu->send($player);
    }
}