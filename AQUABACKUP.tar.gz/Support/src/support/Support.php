<?php

declare(strict_types=1);

namespace support;

use JsonException;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use support\command\SupportCommand;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use support\npc\SupportEntity;

/**
 * Class Support
 * @package support
 */
class Support extends PluginBase
{
    use SingletonTrait;
    
    /** @var array */
    private array $partners = [], $players = [];
    
    public function onLoad(): void
    {
        self::setInstance($this);
    }
    
    public function onEnable(): void
    {
        # Libs
        if (!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
        
        # Save default configuration
        $this->saveDefaultConfig();
        
        # Create folders
        if (!file_exists($this->getDataFolder() . 'database'))
            @mkdir($this->getDataFolder() . 'database');
        $configPlayers = new Config($this->getDataFolder() . 'database/players.json', Config::JSON, []);
        $configPartners = new Config($this->getDataFolder() . 'database/partners.json', Config::JSON, [
            'organization' => [],
            'types' => []
        ]);

        $this->players = $configPlayers->getAll();
        $this->partners = $configPartners->getAll();

        EntityFactory::getInstance()->register(SupportEntity::class, function (World $world, CompoundTag $nbt): SupportEntity {
            return new SupportEntity(EntityDataHelper::parseLocation($nbt, $world), SupportEntity::parseSkinNBT($nbt), $nbt);
        }, ['SupportEntity']);
        
        # Register command
        $this->getServer()->getCommandMap()->register('Support', new SupportCommand());
    }

    /**
     * @throws JsonException
     */
    public function onDisable(): void
    {
        if (is_array($this->partners) && is_array($this->players)) {
            $configPlayers = new Config($this->getDataFolder() . 'database/players.json', Config::JSON, []);
            $configPartners = new Config($this->getDataFolder() . 'database/partners.json', Config::JSON, [
                'organization' => [],
                'types' => []
            ]);
            
            $configPlayers->setAll($this->players);
            $configPlayers->save();
            
            $configPartners->setAll($this->partners);
            $configPartners->save();
        }
    }
    
    /**
     * @return array
     */
    public function getPartners(): array
    {
        return $this->partners;
    }
    
    /**
     * @return array
     */
    public function getPlayers(): array
    {
        return $this->players;
    }

    /**
     * @param string $name
     * @return array|null
     */
    public function getPartner(string $name): ?array
    {
        return $this->partners['types'][$name] ?? null;
    }

    /**
     * @param string $name
     * @return array|null
     */
    public function getPlayer(string $name): ?array
    {
        return $this->players[$name] ?? null;
    }

    /**
     * @param string $partnerName
     * @param string $format
     */
    public function addPartner(string $partnerName, string $format): void
    {
        $this->partners['types'][$partnerName] = [
            'format' => $format,
            'amount_support' => 0
        ];
    }
    
    /**
     * @param string $partnerName
     */
    public function addSupport(string $partnerName): void
    {
        $this->partners['types'][$partnerName]['amount_support']++;
    }

    /**
     * @param string $partnerName
     */
    public function removePartner(string $partnerName): void
    {
        unset($this->partners['types'][$partnerName]);
    }
    
    /**
     * @param int $slot
     * @param string $partnerName
     */
    public function setSlotOrganization(int $slot, string $partnerName): void
    {
        $this->partners['organization'][$slot] = $partnerName;
    }
    
    /**
     * @param string $partnerName
     */
    public function removeSlotOrganization(string $partnerName): void
    {
        $key = array_search($partnerName, $this->partners['organization']);
        unset($this->partners['organization'][$key]);
    }
    
    public function resetSlotsOrganization(): void
    {
        $this->partners['organization'] = [];
    }
    
    /**
     * @param string $name
     * @param int $minutes
     * @param string $partner
     */
    public function setPlayer(string $name, int $minutes, string $partner): void
    {
        $this->players[$name] = [
            'time' => time() + ($minutes * 60),
            'last_support' => $partner
        ];
    }
}