<?php

declare(strict_types=1);

namespace support\command;

use hcf\module\blockshop\utils\Utils as UtilsUtils;
use support\Support;
use support\utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use support\npc\SupportEntity;

/**
 * Class SupportCommand
 * @package support\command
 */
class SupportCommand extends Command
{
    
    /**
     * SupportCommand construct.
     */
    public function __construct()
    {
        parent::__construct('support', 'support your favorite partner');
        $this->setPermission('use.player.command');
    }
    
    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player)
            return;
        
        if (!isset($args[0])) {
            Utils::openSupportChest($sender);
            return;
        }
        
        switch (strtolower($args[0])) {
            case 'edit':
                if (!$sender->hasPermission('edit.support.permission')) return;
                Utils::openSupportEditChest($sender);
                break;

            case 'npc':
                if (!$sender->hasPermission('edit.support.permission')) return;
                $entity = new SupportEntity($sender->getLocation(), $sender->getSkin(), UtilsUtils::createBasicNBT($sender));
                $entity->spawnToAll();
                break;
           
            case 'create':
               if (!$sender->hasPermission('create.support.permission')) return;
               
               if (!isset($args[1])) {
                   $sender->sendMessage(TextFormat::colorize('&cInsufficient arguments. Enter the name of the partner'));
                   return;
               }
               
               if (!isset($args[2])) {
                   $sender->sendMessage(TextFormat::colorize('&cInsufficient arguments. Enter the format of the partner\'s name'));
                   return;
               }
               Support::getInstance()->addPartner($args[1], $args[2]);
               $sender->sendMessage(TextFormat::colorize('&aYou created a new partner to support. Please put it in the partner chest &7(/support edit)'));
               
               $sender->getInventory()->addItem(Utils::makeItem($args[1]));
               break;
               
            case 'remove':
               if (!$sender->hasPermission('remove.support.permission')) return;
               
               if (!isset($args[1])) {
                   $sender->sendMessage(TextFormat::colorize('&cInsufficient arguments. Enter the name of the partner'));
                   return;
               }
               Support::getInstance()->removePartner($args[1]);
               $sender->sendMessage(TextFormat::colorize('&cYou have successfully removed the partner'));
               break;
        }
    }
}